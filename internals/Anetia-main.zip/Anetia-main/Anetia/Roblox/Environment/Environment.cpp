#include <Roblox/Environment/Environment.hpp>
#include <Roblox/Environment/Libraries/Http.hpp>
#include <Roblox/Environment/Libraries/Closures.hpp>
#include <Roblox/Environment/Libraries/Misc.hpp>
#include <Roblox/Environment/Libraries/Filesystem.hpp>
#include <Roblox/Environment/Libraries/Crypt.hpp>
#include <Roblox/Environment/Libraries/Cache.hpp>
#include <Roblox/Environment/Libraries/Metatable.hpp>
#include <Roblox/Environment/Libraries/Drawing.hpp>
#include <Roblox/Environment/Libraries/Instance.hpp>
#include <Roblox/Environment/Libraries/Script.hpp>
#include <Roblox/Environment/Libraries/Debug.hpp>
#include <Roblox/Environment/Libraries/Input.hpp>
#include <Roblox/Environment/Libraries/Raknet.hpp>
#include <Roblox/Environment/Libraries/Websocket.hpp>

lua_CFunction OriginalIndex;
lua_CFunction OriginalNamecall;
lua_CFunction OriginalNewindex;


std::vector<const char*> UnsafeFunction = {
    ("Load"), ("OpenScreenshotsFolder"), ("OpenVideosFolder"),
    ("AddCoreScriptLocal"), ("SaveScriptProfilingData"),
    ("GetRobuxBalance"), ("PerformPurchase"), ("PerformPurchaseV2"), ("PerformBulkPurchase"),
    ("PerformSubscriptionPurchase"), ("PerformSubscriptionPurchaseV2"), ("PerformCancelSubscription"),
    ("PromptPurchase"), ("PromptProductPurchase"), ("PromptGamePassPurchase"), ("PromptBundlePurchase"),
    ("PromptBulkPurchase"), ("PromptRobloxPurchase"), ("PromptThirdPartyPurchase"),
    ("PromptPremiumPurchase"), ("PromptSubscriptionPurchase"), ("PromptCancelSubscription"),
    ("PromptNativePurchase"), ("PromptNativePurchaseWithLocalPlayer"), ("PromptCollectiblesPurchase"),
    ("PrepareCollectiblesPurchase"), ("GetUserSubscriptionPaymentHistoryAsync"),
    ("GetUserSubscriptionDetailsInternalAsync"), ("GetUserSubscriptionStatusAsync"),
    ("ReportAbuse"), ("ReportAbuseV3"),
    ("TakeScreenshot"), ("ToggleRecording"),
    ("OpenBrowserWindow"), ("OpenNativeOverlay"), ("ExecuteJavaScript"), ("ReturnToJavaScript"),
    ("SendCommand"), ("EmitHybridEvent"), ("OpenWeChatAuthWindow"),
    ("BroadcastNotification"), ("SetPurchasePromptIsShown"),
    ("OpenUrl"), ("DetectUrl"), ("RegisterLuaUrl"), ("StartLuaUrlDelivery"), ("StopLuaUrlDelivery"),
    ("SwitchToSettingsApp"), ("SupportsSwitchToSettingsApp"), ("GetLastLuaUrl"),
    ("GetAndClearLastPendingUrl"), ("IsUrlRegistered"),
    ("RequestInternal"), ("RequestAsync"), ("GetAsync"), ("PostAsync"),
    ("GetAsyncFullUrl"), ("PostAsyncFullUrl"), ("RequestLimitedAsync"),
    ("HttpRequestAsync"), ("GetApiV1"), ("InvokeAsync"), ("RegisterOpenCloud"),
    ("CaptureScreenshot"), ("CreatePostAsync"), ("DeleteCapture"), ("DeleteCapturesAsync"),
    ("GetCaptureFilePathAsync"), ("GetCaptureUploadDataAsync"), ("GetCaptureSizeAsync"),
    ("GetCaptureStorageSizeAsync"), ("RetrieveCaptures"), ("SaveCaptureToExternalStorage"),
    ("SaveCapturesToExternalStorageAsync"), ("SaveScreenshotCapture"),
    ("PromptSaveCapturesToGallery"), ("PromptShareCapture"),
    ("Call"), ("GetLast"), ("GetMessageId"), ("GetProtocolMethodRequestMessageId"),
    ("GetProtocolMethodResponseMessageId"), ("MakeRequest"), ("Publish"),
    ("PublishProtocolMethodRequest"), ("PublishProtocolMethodResponse"), ("Subscribe"),
    ("SubscribeToProtocolMethodRequest"), ("SubscribeToProtocolMethodResponse"),
    ("GetCredentialsHeaders"), ("GetDeviceAccessToken"), ("GetDeviceIntegrityToken"),
    ("GetDeviceIntegrityTokenYield"),
    ("NoPromptCreateOutfit"), ("NoPromptDeleteOutfit"), ("NoPromptRenameOutfit"), ("NoPromptSaveAvatar"),
    ("NoPromptSaveAvatarThumbnailCustomization"), ("NoPromptSetFavorite"), ("NoPromptUpdateOutfit"),
    ("PerformCreateOutfitWithDescription"), ("PerformDeleteOutfit"), ("PerformRenameOutfit"),
    ("PerformSaveAvatarWithDescription"), ("PerformSetFavorite"), ("PerformUpdateOutfit"),
    ("PromptCreateOutfit"), ("PromptDeleteOutfit"), ("PromptRenameOutfit"), ("PromptSaveAvatar"),
    ("PromptSetFavorite"), ("PromptUpdateOutfit"), ("SetAllowInventoryReadAccess"),
    ("PromptAllowInventoryReadAccess"), ("SignalCreateOutfitFailed"), ("SignalCreateOutfitPermissionDenied"),
    ("SignalDeleteOutfitFailed"), ("SignalDeleteOutfitPermissionDenied"), ("SignalRenameOutfitFailed"),
    ("SignalRenameOutfitPermissionDenied"), ("SignalSaveAvatarPermissionDenied"),
    ("SignalSetFavoriteFailed"), ("SignalSetFavoritePermissionDenied"), ("SignalUpdateOutfitFailed"),
    ("SignalUpdateOutfitPermissionDenied"),
    ("GetLocalFileContents"),
    ("SetBaseUrl"),
    ("FetchAssetWithFormat"), ("RegisterUGCValidationFunction"),
    ("PerformManagedUpdate"),
    ("TestService.Run"), ("TestService"), ("Run"),
};

static bool ContainsEmoji(const std::string& str)
{
    for (size_t i = 0; i < str.size(); i++)
    {
        unsigned char c = (unsigned char)str[i];
        if (c == 0xF0 && i + 3 < str.size())
        {
            unsigned char n1 = (unsigned char)str[i + 1];
            unsigned char n2 = (unsigned char)str[i + 2];
            unsigned char n3 = (unsigned char)str[i + 3];
            if (n1 >= 0x90 && n1 <= 0x9F && n2 >= 0x80 && n2 <= 0xBF && n3 >= 0x80 && n3 <= 0xBF)
                return true;
        }
    }
    return false;
}

int IndexHook(lua_State* L)

{
    if (L->userdata->capabilities == MaxCapabilities && L->userdata->source.expired())
    {
        std::string Key = lua_isstring(L, 2) ? lua_tostring(L, 2) : "";

        if (ContainsEmoji(Key))
        {
            luaL_error(L, ("Blocked: vulnerable character detected"));
            return 0;
        }

        for (const char* Function : UnsafeFunction)
        {
            if (Key == Function)
            {
                luaL_error(L, ("Function '%s' has been blocked for security reasons"), Function);
                return 0;
            }
        }

        if (Key == ("HttpGet") || Key == ("HttpGetAsync"))
        {
            lua_pushcclosure(L, Http::HttpGet, nullptr, NULL);
            return 1;
        }
        else if (Key == ("HttpPost") || Key == ("HttpPostAsync"))
        {
            luaL_error(L, ("HttpPost has been blocked for security reasons"));
            return 0;
        }
        else if (Key == ("GetObjects"))
        {
            lua_pushcclosure(L, Miscellaneous::getobjects, nullptr, NULL);
            return 1;
        }
    }

    return OriginalIndex(L);
};

int NamecallHook(lua_State* L)
{
    if (L->userdata->capabilities == MaxCapabilities && L->userdata->source.expired())
    {
        std::string Key = L->namecall->data;

        if (ContainsEmoji(Key))
        {
            luaL_error(L, ("Blocked: vulnerable character detected"));
            return 0;
        }

        for (const char* Function : UnsafeFunction)
        {
            if (Key == Function)
            {
                luaL_error(L, ("Function '%s' has been blocked for security reasons"), Function);
                return 0;
            }
        }

        if (Key == ("HttpGet") || Key == ("HttpGetAsync"))
        {
            return Http::HttpGet(L);
        }
        else if (Key == ("HttpPost") || Key == ("HttpPostAsync"))
        {
            luaL_error(L, ("HttpPost has been blocked for security reasons"));
            return 0;
        }
        else if (Key == ("GetObjects"))
        {
            return Miscellaneous::getobjects(L);
        }
    }

    return OriginalNamecall(L);
};

int NewindexHook(lua_State* L)
{
    if (lua_type(L, 1) == LUA_TUSERDATA && lua_type(L, 2) == LUA_TSTRING)
    {
        const char* prop = lua_tostring(L, 2);
        if (strcmp(prop, ("OnInvoke")) == 0 || strcmp(prop, ("OnClientInvoke")) == 0 || strcmp(prop, ("OnServerInvoke")) == 0)
        {
            int top = lua_gettop(L);
            lua_pushstring(L, ("__callbacks"));
            lua_rawget(L, LUA_REGISTRYINDEX);
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 1);
                lua_newtable(L);

                lua_newtable(L);
                lua_pushstring(L, ("k"));
                lua_setfield(L, -2, ("__mode"));
                lua_setmetatable(L, -2);

                lua_pushstring(L, ("__callbacks"));
                lua_pushvalue(L, -2);
                lua_rawset(L, LUA_REGISTRYINDEX);
            }

            lua_pushvalue(L, 1);
            lua_rawget(L, -2);
            if (lua_isnil(L, -1))
            {
                lua_pop(L, 1);
                lua_newtable(L);

                lua_pushvalue(L, 1);
                lua_pushvalue(L, -2);
                lua_rawset(L, -4);
            }

            lua_pushstring(L, prop);
            lua_pushvalue(L, 3);
            lua_rawset(L, -3);

            lua_settop(L, top);
        }
    }

    return OriginalNewindex(L);
}

void InitializeHooks(lua_State* L)
{
    int OriginalTop = lua_gettop(L);

    lua_getglobal(L, ("game"));
    luaL_getmetafield(L, -1, ("__index"));
    if (lua_type(L, -1) == LUA_TFUNCTION || lua_type(L, -1) == LUA_TLIGHTUSERDATA)
    {
        Closure* IndexClosure = clvalue(luaA_toobject(L, -1));
        OriginalIndex = IndexClosure->c.f;
        IndexClosure->c.f = IndexHook;
    }
    lua_pop(L, 1);

    luaL_getmetafield(L, -1, ("__newindex"));
    if (lua_type(L, -1) == LUA_TFUNCTION || lua_type(L, -1) == LUA_TLIGHTUSERDATA)
    {
        Closure* NewindexClosure = clvalue(luaA_toobject(L, -1));
        OriginalNewindex = NewindexClosure->c.f;
        NewindexClosure->c.f = NewindexHook;
    }
    lua_pop(L, 1);

    luaL_getmetafield(L, -1, ("__namecall"));
    if (lua_type(L, -1) == LUA_TFUNCTION || lua_type(L, -1) == LUA_TLIGHTUSERDATA)
    {
        Closure* NamecallClosure = clvalue(luaA_toobject(L, -1));
        OriginalNamecall = NamecallClosure->c.f;
        NamecallClosure->c.f = NamecallHook;
    }
    lua_pop(L, 1);

    lua_settop(L, OriginalTop);


}
void Environment::Initialize(lua_State* L)
{
    std::memset(L->global->udatadirect, 0, sizeof(L->global->udatadirect));
    std::memset(L->global->udatadirectfields, 0, sizeof(L->global->udatadirectfields));
    

    Shared::RobloxPcallRef = LUA_NOREF;

    lua_getglobal(L, "pcall");
    if (lua_isfunction(L, -1))
        Shared::RobloxPcallRef = lua_ref(L, -1);
    lua_pop(L, 1);

    Closures::RegisterLibrary(L);
    Http::RegisterLibrary(L);
    Miscellaneous::RegisterLibrary(L);
    Filesystem::RegisterLibrary(L);
    Crypt::RegisterLibrary(L);
    Cache::RegisterLibrary(L);
    Metatable::RegisterLibrary(L);
    Drawing::RegisterLibrary(L);
    Script::RegisterLibrary(L);
    Instance::RegisterLibrary(L);
    Debug::RegisterLibrary(L);
    Input::RegisterLibrary(L);
    Raknet::RegisterLibrary(L);
    WebsocketLib(L);

    InitializeHooks(L);
    luaL_sandboxthread(L);

    lua_newtable(L);
    lua_setglobal(L, "_G");

    lua_newtable(L);
    lua_setglobal(L, "shared");

    std::string scriptsrc = R"LUA(local function noop() end
local function noop_str() return "" end

getgenv().rconsolecreate = noop
getgenv().consolecreate = noop
getgenv().rconsoledestroy = noop
getgenv().consoledestroy = noop
getgenv().rconsoleclear = noop
getgenv().consoleclear = noop
getgenv().rconsoleprint = noop
getgenv().consoleprint = noop
getgenv().rconsolesettitle = noop
getgenv().rconsolename = noop
getgenv().consolesettitle = noop
getgenv().rconsoleinput = noop_str
getgenv().consoleinput = noop_str
getgenv().rconsoleinfo = noop
getgenv().rconsoleshow = noop
getgenv().rconsolehide = noop
getgenv().rconsoleerr = noop_str
getgenv().rconsolewarn = noop_str)LUA";


    TaskScheduler::SendScript(scriptsrc);

    std::vector<std::string> TeleportScripts;
    {
        std::lock_guard<std::mutex> lock(Shared::TeleportQueueMutex);
        TeleportScripts.swap(Shared::TeleportQueue);
    }
    for (std::string& Script : TeleportScripts)
        TaskScheduler::SendScript(std::move(Script));

}