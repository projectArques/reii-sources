#pragma once

#include <map>
#include <string>
#include <sstream>
#include <lstate.h>
#include <lualib.h>
#include <optional>
#include <algorithm>
#include <Windows.h>

#include <cpr/cpr.h>
#include <Roblox/Shared/Shared.hpp>
#include <Dependencies/nlohmann/json.hpp>
#include <Roblox/Environment/Yielding/Yielding.hpp>

enum RequestMethods
{
    H_GET,
    H_HEAD,
    H_POST,
    H_PUT,
    H_DELETE,
    H_OPTIONS
};

std::map<std::string, RequestMethods> RequestMethodMap = {
   { "get", H_GET },
   { "head", H_HEAD },
   { "post", H_POST },
   { "put", H_PUT },
   { "delete", H_DELETE },
   { "options", H_OPTIONS }
};

namespace Http
{
    int DoRequest(lua_State* L, const std::string& Url, const cpr::Header& Headers)
    {
        cpr::Response Result;
        std::string Error;
        try
        {
            Result = cpr::Get(cpr::Url{ Url }, Headers);
        }
        catch (const std::exception& ex)
        {
            Error = ex.what();
        }
        catch (...)
        {
            Error = "unknown exception";
        }

        if (Result.status_code < 200 || Result.status_code > 299)
        {
            std::string msg = !Error.empty() ? Error
                : (!Result.error.message.empty() ? Result.error.message : "unknown error");

            std::stringstream ss;
            ss << "-- [[ HttpGet failed ]]\n-- [[ Response "
               << Result.status_code << " - " << msg
               << " ]]\n-- [[ " << msg << " ]]";

            lua_pushstring(L, ss.str().c_str());
            return 1;
        }

        lua_pushlstring(L, Result.text.data(), Result.text.size());
        return 1;
    }

    int HttpGet(lua_State* L)
    {
        std::string Url;

        if (!lua_isstring(L, 1))
        {
            luaL_checkstring(L, 2);
            Url = lua_tostring(L, 2);
        }
        else
        {
            Url = lua_tostring(L, 1);
        }

        if (Url.find("http://") != 0 && Url.find("https://") != 0)
        {
            luaL_argerror(L, 2, "Invalid protocol (expected 'http://' or 'https://')");
            return 0;
        }

        std::string GameId;
        lua_getglobal(L, "game");
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, "GameId");
            if (lua_isstring(L, -1))
                GameId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        std::string PlaceId;
        lua_getglobal(L, "game");
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, "PlaceId");
            if (lua_isstring(L, -1))
                PlaceId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        HW_PROFILE_INFO hwProfileInfo;
        std::optional<std::string> HWID;
        if (GetCurrentHwProfile(&hwProfileInfo))
        {
            std::wstring wGuid(hwProfileInfo.szHwProfileGuid);
            std::string Guid(wGuid.begin(), wGuid.end());
            HWID = Guid;
        }

        using Json = nlohmann::json;
        cpr::Header Headers;
        Json SessionIdJson;

        SessionIdJson["GameId"] = GameId;
        SessionIdJson["PlaceId"] = PlaceId;

        Headers.insert({ "User-Agent", "Anetia/1.0" });
        Headers.insert({ "Roblox-Session-Id", SessionIdJson.dump() });
        Headers.insert({ "Roblox-Place-Id", PlaceId });
        Headers.insert({ "Roblox-Game-Id", GameId });
        Headers.insert({ "Anetia-Fingerprint", HWID.value_or("Unknown") });
        Headers.insert({ "Accept", "*/*" });

        return Yielding::YieldExecution(L, [=]() -> std::function<int(lua_State*)>
            {
                cpr::Response Result;
                std::string Error;
                try
                {
                    Result = cpr::Get(cpr::Url{ Url }, Headers);
                }
                catch (const std::exception& ex)
                {
                    Error = ex.what();
                }
                catch (...)
                {
                    Error = "unknown exception";
                }

                return [Result, Error](lua_State* L) -> int
                    {
                        if (Result.status_code < 200 || Result.status_code > 299)
                        {
                            std::string msg = !Error.empty() ? Error
                                : (!Result.error.message.empty() ? Result.error.message : "unknown error");

                            std::stringstream ss;
                            ss << "-- [[ HttpGet failed ]]\n-- [[ Response "
                               << Result.status_code << " - " << msg
                               << " ]]\n-- [[ " << msg << " ]]";

                            lua_pushstring(L, ss.str().c_str());
                            return 1;
                        }

                        lua_pushlstring(L, Result.text.data(), Result.text.size());
                        return 1;
                    };
            });
    }

    int request(lua_State* L)
    {
        luaL_checktype(L, 1, LUA_TTABLE);

        lua_getfield(L, 1, "Url");
        if (!lua_isstring(L, -1))
            luaL_error(L, "Missing or invalid 'Url'");

        std::string Url = lua_tostring(L, -1);
        lua_pop(L, 1);

        if (Url.find("http://") != 0 && Url.find("https://") != 0)
        {
            luaL_error(L, "Invalid protocol (expected 'http://' or 'https://')");
            return 0;
        }

        auto Method = H_GET;
        lua_getfield(L, 1, "Method");
        if (lua_isstring(L, -1))
        {
            std::string MethodStr = lua_tostring(L, -1);
            std::transform(MethodStr.begin(), MethodStr.end(), MethodStr.begin(), ::tolower);
            if (!RequestMethodMap.count(MethodStr))
                luaL_error(L, "Invalid request method: '%s'", MethodStr.c_str());

            Method = RequestMethodMap[MethodStr];
        }
        lua_pop(L, 1);

        cpr::Header Headers;
        lua_getfield(L, 1, "Headers");
        if (lua_istable(L, -1))
        {
            lua_pushnil(L);
            while (lua_next(L, -2))
            {
                if (!lua_isstring(L, -2) || !lua_isstring(L, -1))
                    luaL_error(L, "'Headers' must have string keys/values");

                std::string Key = lua_tostring(L, -2);
                if (_stricmp(Key.c_str(), "Content-Length") == 0)
                    luaL_error(L, "'Content-Length' cannot be overwritten");

                Headers[Key] = lua_tostring(L, -1);
                lua_pop(L, 1);
            }
        }
        lua_pop(L, 1);

        cpr::Cookies Cookies;
        lua_getfield(L, 1, "Cookies");
        if (lua_istable(L, -1))
        {
            lua_pushnil(L);
            while (lua_next(L, -2))
            {
                if (!lua_isstring(L, -2) || !lua_isstring(L, -1))
                    luaL_error(L, "'Cookies' must have string keys/values");

                Cookies[lua_tostring(L, -2)] = lua_tostring(L, -1);
                lua_pop(L, 1);
            }
        }
        lua_pop(L, 1);

        std::string Body;
        lua_getfield(L, 1, "Body");
        if (lua_isstring(L, -1))
        {
            if (Method == H_GET || Method == H_HEAD)
                luaL_error(L, "'Body' is not allowed for GET/HEAD requests");

            Body = lua_tostring(L, -1);
        }
        lua_pop(L, 1);

        std::string GameId;
        lua_getglobal(L, "game");
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, "GameId");
            if (lua_isstring(L, -1))
                GameId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        std::string PlaceId;
        lua_getglobal(L, "game");
        if (lua_istable(L, -1))
        {
            lua_getfield(L, -1, "PlaceId");
            if (lua_isstring(L, -1))
                PlaceId = lua_tostring(L, -1);

            lua_pop(L, 1);
        }
        lua_pop(L, 1);

        HW_PROFILE_INFO hwProfileInfo;
        std::optional<std::string> HWID;
        if (GetCurrentHwProfile(&hwProfileInfo))
        {
            std::wstring wGuid(hwProfileInfo.szHwProfileGuid);
            std::string Guid(wGuid.begin(), wGuid.end());
            HWID = Guid;
        }

        nlohmann::json SessionIdJson;
        SessionIdJson["GameId"] = GameId;
        SessionIdJson["PlaceId"] = PlaceId;

        Headers.insert({ "User-Agent", "Anetia/1.0" });
        Headers.insert({ "Roblox-Session-Id", SessionIdJson.dump() });
        Headers.insert({ "Anetia-Fingerprint", HWID.value_or("Unknown") });

        return Yielding::YieldExecution(L, [=]() -> std::function<int(lua_State*)>
            {
                cpr::Response Response;
                try
                {
                    switch (Method)
                    {
                    case H_GET: Response = cpr::Get(cpr::Url{ Url }, Cookies, Headers); break;
                    case H_HEAD: Response = cpr::Head(cpr::Url{ Url }, Cookies, Headers); break;
                    case H_POST: Response = cpr::Post(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers); break;
                    case H_PUT: Response = cpr::Put(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers); break;
                    case H_DELETE: Response = cpr::Delete(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers); break;
                    case H_OPTIONS: Response = cpr::Options(cpr::Url{ Url }, cpr::Body{ Body }, Cookies, Headers); break;
                    default: throw std::runtime_error("Invalid request method"); break;
                    }
                }
                catch (const std::exception& ex)
                {
                    std::string Err = std::string("Request failed: ") + ex.what();
                    return [Err](lua_State* L) -> int
                        {
                            lua_pushstring(L, Err.c_str());
                            return 1;
                        };
                }

                return [Response](lua_State* L) -> int
                    {
                        if (Response.error.code != cpr::ErrorCode::OK)
                        {
                            std::string Err = "Request failed: " + Response.error.message;
                            lua_pushstring(L, Err.c_str());
                            return 1;
                        }

                        lua_newtable(L);
                        lua_pushboolean(L, Response.status_code >= 200 && Response.status_code < 300);
                        lua_setfield(L, -2, "Success");

                        lua_pushinteger(L, Response.status_code);
                        lua_setfield(L, -2, "StatusCode");

                        std::string Phrase;
                        switch (Response.status_code)
                        {
                        case 100: Phrase = "Continue"; break;
                        case 101: Phrase = "Switching Protocols"; break;
                        case 102: Phrase = "Processing"; break;
                        case 103: Phrase = "Early Hints"; break;

                        case 200: Phrase = "OK"; break;
                        case 201: Phrase = "Created"; break;
                        case 202: Phrase = "Accepted"; break;
                        case 203: Phrase = "Non-Authoritative Information"; break;
                        case 204: Phrase = "No Content"; break;
                        case 205: Phrase = "Reset Content"; break;
                        case 206: Phrase = "Partial Content"; break;
                        case 207: Phrase = "Multi-Status"; break;
                        case 208: Phrase = "Already Reported"; break;
                        case 226: Phrase = "IM Used"; break;

                        case 300: Phrase = "Multiple Choices"; break;
                        case 301: Phrase = "Moved Permanently"; break;
                        case 302: Phrase = "Found"; break;
                        case 303: Phrase = "See Other"; break;
                        case 304: Phrase = "Not Modified"; break;
                        case 305: Phrase = "Use Proxy"; break;
                        case 307: Phrase = "Temporary Redirect"; break;
                        case 308: Phrase = "Permanent Redirect"; break;

                        case 400: Phrase = "Bad Request"; break;
                        case 401: Phrase = "Unauthorized"; break;
                        case 402: Phrase = "Payment Required"; break;
                        case 403: Phrase = "Forbidden"; break;
                        case 404: Phrase = "Not Found"; break;
                        case 405: Phrase = "Method Not Allowed"; break;
                        case 406: Phrase = "Not Acceptable"; break;
                        case 407: Phrase = "Proxy Authentication Required"; break;
                        case 408: Phrase = "Request Timeout"; break;
                        case 409: Phrase = "Conflict"; break;
                        case 410: Phrase = "Gone"; break;
                        case 411: Phrase = "Length Required"; break;
                        case 412: Phrase = "Precondition Failed"; break;
                        case 413: Phrase = "Payload Too Large"; break;
                        case 414: Phrase = "URI Too Long"; break;
                        case 415: Phrase = "Unsupported Media Type"; break;
                        case 416: Phrase = "Range Not Satisfiable"; break;
                        case 417: Phrase = "Expectation Failed"; break;
                        case 418: Phrase = "I'm a teapot"; break;
                        case 422: Phrase = "Unprocessable Entity"; break;
                        case 423: Phrase = "Locked"; break;
                        case 424: Phrase = "Failed Dependency"; break;
                        case 426: Phrase = "Upgrade Required"; break;
                        case 428: Phrase = "Precondition Required"; break;
                        case 429: Phrase = "Too Many Requests"; break;
                        case 431: Phrase = "Request Header Fields Too Large"; break;
                        case 451: Phrase = "Unavailable For Legal Reasons"; break;

                        case 500: Phrase = "Internal Server Error"; break;
                        case 501: Phrase = "Not Implemented"; break;
                        case 502: Phrase = "Bad Gateway"; break;
                        case 503: Phrase = "Service Unavailable"; break;
                        case 504: Phrase = "Gateway Time-out"; break;
                        case 505: Phrase = "HTTP Version Not Supported"; break;
                        case 506: Phrase = "Variant Also Negotiates"; break;
                        case 507: Phrase = "Insufficient Storage"; break;
                        case 508: Phrase = "Loop Detected"; break;
                        case 510: Phrase = "Not Extended"; break;
                        case 511: Phrase = "Network Authentication Required"; break;

                        default: Phrase = std::string(); break;
                        }
                        lua_pushstring(L, Phrase.c_str());
                        lua_setfield(L, -2, "StatusMessage");

                        lua_newtable(L);
                        for (auto& Header : Response.header)
                        {
                            lua_pushstring(L, Header.first.c_str());
                            lua_pushstring(L, Header.second.c_str());
                            lua_settable(L, -3);
                        }
                        lua_setfield(L, -2, "Headers");

                        lua_newtable(L);
                        for (auto& C : Response.cookies.map_)
                        {
                            lua_pushstring(L, C.first.c_str());
                            lua_pushstring(L, C.second.c_str());
                            lua_settable(L, -3);
                        }
                        lua_setfield(L, -2, "Cookies");

                        lua_pushlstring(L, Response.text.data(), Response.text.size());
                        lua_setfield(L, -2, "Body");

                        return 1;
                    };
            });
    }

    void RegisterLibrary(lua_State* L)
    {
        Utils::AddFunction(L, "HttpGet", Http::HttpGet);
        Utils::AddFunction(L, "request", Http::request);
        Utils::AddFunction(L, "http_request", Http::request);

        lua_newtable(L);
        Utils::AddTableFunction(L, "request", Http::request);
        lua_setglobal(L, "http");
    }
}