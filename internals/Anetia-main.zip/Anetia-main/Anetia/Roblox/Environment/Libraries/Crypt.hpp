#pragma once

#include <lgc.h>
#include <lstate.h>
#include <lualib.h>
#include <string>
#include <vector>

#include <Roblox/Shared/Shared.hpp>

#include <Dependencies/cryptopp/include/cryptopp/aes.h>
#include <Dependencies/cryptopp/include/cryptopp/rsa.h>
#include <Dependencies/cryptopp/include/cryptopp/gcm.h>
#include <Dependencies/cryptopp/include/cryptopp/eax.h>
#include <Dependencies/cryptopp/include/cryptopp/md2.h>
#include <Dependencies/cryptopp/include/cryptopp/md5.h>
#include <Dependencies/cryptopp/include/cryptopp/sha.h>
#include <Dependencies/cryptopp/include/cryptopp/sha3.h>
#include <Dependencies/cryptopp/include/cryptopp/osrng.h>
#include <Dependencies/cryptopp/include/cryptopp/hex.h>
#include <Dependencies/cryptopp/include/cryptopp/pssr.h>
#include <Dependencies/cryptopp/include/cryptopp/base64.h>
#include <Dependencies/cryptopp/include/cryptopp/modes.h>
#include <Dependencies/cryptopp/include/cryptopp/filters.h>
#include <Dependencies/cryptopp/include/cryptopp/serpent.h>
#include <Dependencies/cryptopp/include/cryptopp/pwdbased.h>
#include <Dependencies/cryptopp/include/cryptopp/blowfish.h>
#include <Dependencies/cryptopp/include/cryptopp/rdrand.h>

#include <windows.h>
#include <rpc.h>
#include <rpcndr.h>
#include <map>

namespace sha_detail {
    static const uint64_t K384[80] = {
        0x428a2f98d728ae22ULL,0x7137449123ef65cdULL,0xb5c0fbcfec4d3b2fULL,0xe9b5dba58189dbbcULL,
        0x3956c25bf348b538ULL,0x59f111f1b605d019ULL,0x923f82a4af194f9bULL,0xab1c5ed5da6d8118ULL,
        0xd807aa98a3030242ULL,0x12835b0145706fbeULL,0x243185be4ee4b28cULL,0x550c7dc3d5ffb4e2ULL,
        0x72be5d74f27b896fULL,0x80deb1fe3b1696b1ULL,0x9bdc06a725c71235ULL,0xc19bf174cf692694ULL,
        0xe49b69c19ef14ad2ULL,0xefbe4786384f25e3ULL,0x0fc19dc68b8cd5b5ULL,0x240ca1cc77ac9c65ULL,
        0x2de92c6f592b0275ULL,0x4a7484aa6ea6e483ULL,0x5cb0a9dcbd41fbd4ULL,0x76f988da831153b5ULL,
        0x983e5152ee66dfabULL,0xa831c66d2db43210ULL,0xb00327c898fb213fULL,0xbf597fc7beef0ee4ULL,
        0xc6e00bf33da88fc2ULL,0xd5a79147930aa725ULL,0x06ca6351e003826fULL,0x142929670a0e6e70ULL,
        0x27b70a8546d22ffcULL,0x2e1b21385c26c926ULL,0x4d2c6dfc5ac42aedULL,0x53380d139d95b3dfULL,
        0x650a73548baf63deULL,0x766a0abb3c77b2a8ULL,0x81c2c92e47edaee6ULL,0x92722c851482353bULL,
        0xa2bfe8a14cf10364ULL,0xa81a664bbc423001ULL,0xc24b8b70d0f89791ULL,0xc76c51a30654be30ULL,
        0xd192e819d6ef5218ULL,0xd69906245565a910ULL,0xf40e35855771202aULL,0x106aa07032bbd1b8ULL,
        0x19a4c116b8d2d0c8ULL,0x1e376c085141ab53ULL,0x2748774cdf8eeb99ULL,0x34b0bcb5e19b48a8ULL,
        0x391c0cb3c5c95a63ULL,0x4ed8aa4ae3418acbULL,0x5b9cca4f7763e373ULL,0x682e6ff3d6b2b8a3ULL,
        0x748f82ee5defb2fcULL,0x78a5636f43172f60ULL,0x84c87814a1f0ab72ULL,0x8cc702081a6439ecULL,
        0x90befffa23631e28ULL,0xa4506cebde82bde9ULL,0xbef9a3f7b2c67915ULL,0xc67178f2e372532bULL,
        0xca273eceea26619cULL,0xd186b8c721c0c207ULL,0xeada7dd6cde0eb1eULL,0xf57d4f7fee6ed178ULL,
        0x06f067aa72176fbaULL,0x0a637dc5a2c898a6ULL,0x113f9804bef90daeULL,0x1b710b35131c471bULL,
        0x28db77f523047d84ULL,0x32caab7b40c72493ULL,0x3c9ebe0a15c9bebcULL,0x431d67c49c100d4cULL,
        0x4cc5d4becb3e42b6ULL,0x597f299cfc657e2aULL,0x5fcb6fab3ad6faecULL,0x6c44198c4a475817ULL,
    };
    uint64_t rotr64(uint64_t x, int n) { return (x >> n) | (x << (64 - n)); }
    uint64_t ch(uint64_t e, uint64_t f, uint64_t g) { return (e & f) ^ (~e & g); }
    uint64_t maj(uint64_t a, uint64_t b, uint64_t c) { return (a & b) ^ (a & c) ^ (b & c); }
    uint64_t s0(uint64_t a) { return rotr64(a, 28) ^ rotr64(a, 34) ^ rotr64(a, 39); }
    uint64_t s1(uint64_t e) { return rotr64(e, 14) ^ rotr64(e, 18) ^ rotr64(e, 41); }
    uint64_t o0(uint64_t w) { return rotr64(w, 1) ^ rotr64(w, 8) ^ (w >> 7); }
    uint64_t o1(uint64_t w) { return rotr64(w, 19) ^ rotr64(w, 61) ^ (w >> 6); }
}

std::string sha384(const std::string& msg) {
    using namespace sha_detail;
    uint64_t h[8] = {
        0xcbbb9d5dc1059ed8ULL,0x629a292a367cd507ULL,0x9159015a3070dd17ULL,0x152fecd8f70e5939ULL,
        0x67332667ffc00b31ULL,0x8eb44a8768581511ULL,0xdb0c2e0d64f98fa7ULL,0x47b5481dbefa4fa4ULL,
    };

    uint64_t bitlen = (uint64_t)msg.size() * 8;
    std::vector<uint8_t> data(msg.begin(), msg.end());
    data.push_back(0x80);
    while (data.size() % 128 != 112) data.push_back(0x00);
    for (int i = 7; i >= 0; --i) data.push_back(0);
    for (int i = 7; i >= 0; --i) data.push_back((uint8_t)(bitlen >> (i * 8)));

    for (size_t chunk = 0; chunk < data.size(); chunk += 128) {
        uint64_t w[80] = {};
        for (int i = 0; i < 16; ++i) {
            w[i] = 0;
            for (int j = 0; j < 8; ++j)
                w[i] = (w[i] << 8) | data[chunk + i * 8 + j];
        }
        for (int i = 16; i < 80; ++i)
            w[i] = o1(w[i - 2]) + w[i - 7] + o0(w[i - 15]) + w[i - 16];

        uint64_t a = h[0], b = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7];
        for (int i = 0; i < 80; ++i) {
            uint64_t t1 = hh + s1(e) + ch(e, f, g) + K384[i] + w[i];
            uint64_t t2 = s0(a) + maj(a, b, c);
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0] += a; h[1] += b; h[2] += c; h[3] += d; h[4] += e; h[5] += f; h[6] += g; h[7] += hh;
    }

    char buf[97];
    snprintf(buf, sizeof(buf),
        "%016llx%016llx%016llx%016llx%016llx%016llx",
        (unsigned long long)h[0], (unsigned long long)h[1], (unsigned long long)h[2],
        (unsigned long long)h[3], (unsigned long long)h[4], (unsigned long long)h[5]);
    return std::string(buf);
}

enum HashModes
{
    MD5,

    SHA1,

    SHA224,
    SHA256,
    SHA384,
    SHA512,

    SHA3_224,
    SHA3_256,
    SHA3_384,
    SHA3_512,
};

std::map<std::string, HashModes> HashTranslationMap = {
    { "md5", MD5 },

    { "sha1", SHA1 },

    { "sha224", SHA224 },
    { "sha256", SHA256 },
    { "sha384", SHA384 },
    { "sha512", SHA512 },

    { "sha3-224", SHA3_224 },
    { "sha3_224", SHA3_224 },
    { "sha3-256", SHA3_256 },
    { "sha3_256", SHA3_256 },
    { "sha3-384", SHA3_384 },
    { "sha3_384", SHA3_384 },
    { "sha3-512", SHA3_512 },
    { "sha3_512", SHA3_512 },
};

namespace HelpFunctions
{
    template<typename T>
    static std::string hash_with_algo(const std::string& Input)
    {
        T Hash;
        std::string Digest;

        CryptoPP::StringSource SS(Input, true,
            new CryptoPP::HashFilter(Hash,
                new CryptoPP::HexEncoder(
                    new CryptoPP::StringSink(Digest), false
                )));

        return Digest;
    }

    std::string b64encode(const std::string& stringToEncode) {
        std::string base64EncodedString;
        CryptoPP::Base64Encoder encoder{ new CryptoPP::StringSink(base64EncodedString), false };
        encoder.Put((byte*)stringToEncode.c_str(), stringToEncode.length());
        encoder.MessageEnd();

        return base64EncodedString;
    }

    std::string b64decode(const std::string& stringToDecode) {
        std::string base64DecodedString;
        CryptoPP::Base64Decoder decoder{ new CryptoPP::StringSink(base64DecodedString) };
        decoder.Put((byte*)stringToDecode.c_str(), stringToDecode.length());
        decoder.MessageEnd();

        return base64DecodedString;
    }

    std::string RamdonString(int len) {
        static const char* chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        std::string str;
        str.reserve(len);

        for (int i = 0; i < len; ++i) {
            str += chars[rand() % (strlen(chars) - 1)];
        }

        return str;
    }

    void lz4_write_len(std::vector<uint8_t>& out, size_t len)
    {
        while (len >= 255)
        {
            out.push_back(255);
            len -= 255;
        }
        out.push_back(uint8_t(len));
    }

    std::string lz4_compress_block(const uint8_t* src, size_t srcSize)
    {
        const size_t HASH_SIZE = 1u << 16;
        std::vector<int> hash(HASH_SIZE, -1);

        auto read32 = [&](size_t pos) -> uint32_t
            {
                uint32_t v = 0;
                v |= uint32_t(src[pos + 0]) << 0;
                v |= uint32_t(src[pos + 1]) << 8;
                v |= uint32_t(src[pos + 2]) << 16;
                v |= uint32_t(src[pos + 3]) << 24;
                return v;
            };

        auto hash32 = [&](uint32_t v) -> size_t
            {
                return (v * 2654435761u) >> (32 - 16);
            };

        std::vector<uint8_t> out;
        out.reserve(srcSize + srcSize / 8 + 16);

        size_t anchor = 0;
        size_t i = 0;

        while (i + 4 <= srcSize)
        {
            uint32_t seq = read32(i);
            size_t h = hash32(seq);
            int ref = hash[h];
            hash[h] = int(i);

            bool match = false;
            size_t matchPos = 0;

            if (ref >= 0)
            {
                size_t r = size_t(ref);
                if (i > r && (i - r) <= 0xFFFF)
                {
                    if (r + 4 <= srcSize && read32(r) == seq)
                    {
                        match = true;
                        matchPos = r;
                    }
                }
            }

            if (!match)
            {
                i++;
                continue;
            }

            size_t litLen = i - anchor;
            size_t mLen = 4;
            while (i + mLen < srcSize && matchPos + mLen < srcSize && src[i + mLen] == src[matchPos + mLen])
                mLen++;

            uint8_t token = 0;
            uint8_t litNib = uint8_t((std::min)(litLen, size_t(15)));
            uint8_t matchNib = uint8_t((std::min)(mLen - 4, size_t(15)));
            token = uint8_t((litNib << 4) | matchNib);
            out.push_back(token);

            if (litLen >= 15)
                lz4_write_len(out, litLen - 15);

            out.insert(out.end(), src + anchor, src + i);

            uint16_t offset = uint16_t(i - matchPos);
            out.push_back(uint8_t(offset & 0xFF));
            out.push_back(uint8_t((offset >> 8) & 0xFF));

            if (mLen - 4 >= 15)
                lz4_write_len(out, (mLen - 4) - 15);

            i += mLen;
            anchor = i;

            if (i + 4 <= srcSize)
            {
                size_t end = (std::min)(i, srcSize - 4);
                for (size_t p = i - mLen + 1; p <= end; p++)
                {
                    size_t hh = hash32(read32(p));
                    hash[hh] = int(p);
                }
            }
        }

        if (anchor < srcSize)
        {
            size_t litLen = srcSize - anchor;
            uint8_t token = uint8_t(((std::min)(litLen, size_t(15)) << 4) | 0);
            out.push_back(token);
            if (litLen >= 15)
                lz4_write_len(out, litLen - 15);
            out.insert(out.end(), src + anchor, src + srcSize);
        }

        return std::string(reinterpret_cast<const char*>(out.data()), out.size());
    }

    bool lz4_read_len(const uint8_t* in, size_t inSize, size_t& ip, size_t& len)
    {
        size_t s = 0;
        while (true)
        {
            if (ip >= inSize) return false;
            uint8_t v = in[ip++];
            s += v;
            if (v != 255) break;
        }
        len += s;
        return true;
    }

    bool lz4_decompress_block(const uint8_t* in, size_t inSize, std::string& out)
    {
        std::vector<uint8_t> dst;
        dst.reserve(inSize * 3);

        size_t ip = 0;
        while (ip < inSize)
        {
            uint8_t token = in[ip++];
            size_t litLen = (token >> 4) & 0xF;
            size_t matchLen = (token & 0xF);

            if (litLen == 15)
            {
                if (!lz4_read_len(in, inSize, ip, litLen))
                    return false;
            }

            if (ip + litLen > inSize)
                return false;

            dst.insert(dst.end(), in + ip, in + ip + litLen);
            ip += litLen;

            if (ip >= inSize)
                break;

            if (ip + 2 > inSize)
                return false;

            uint16_t offset = uint16_t(in[ip]) | (uint16_t(in[ip + 1]) << 8);
            ip += 2;
            if (offset == 0 || offset > dst.size())
                return false;

            matchLen += 4;
            if ((token & 0xF) == 15)
            {
                if (!lz4_read_len(in, inSize, ip, matchLen))
                    return false;
            }

            size_t start = dst.size() - offset;
            for (size_t k = 0; k < matchLen; k++)
                dst.push_back(dst[start + k]);
        }

        out.assign(reinterpret_cast<const char*>(dst.data()), dst.size());
        return true;
    }
}

namespace Crypt
{
    int base64encode(lua_State* L) {
        
        luaL_trimstack(L, 1);
        luaL_checktype(L, 1, LUA_TSTRING);
        size_t stringLength;
        const char* rawStringToEncode = lua_tolstring(L, 1, &stringLength);
        const std::string stringToEncode(rawStringToEncode, stringLength);
        const std::string encodedString = HelpFunctions::b64encode(stringToEncode);

        lua_pushlstring(L, encodedString.c_str(), encodedString.size());
        return 1;
    }

    int base64decode(lua_State* L) {
        
        luaL_trimstack(L, 1);
        luaL_checktype(L, 1, LUA_TSTRING);
        size_t stringLength;
        const char* rawStringToDecode = lua_tolstring(L, 1, &stringLength);
        const auto stringToDecode = std::string(rawStringToDecode, stringLength);
        const std::string decodedString = HelpFunctions::b64decode(stringToDecode);

        lua_pushlstring(L, decodedString.c_str(), decodedString.size());
        return 1;
    }

    int generatebytes(lua_State* L)
    {
        
        luaL_trimstack(L, 1);
        luaL_checktype(L, 1, LUA_TNUMBER);
        const auto bytesSize = lua_tointeger(L, 1);

        CryptoPP::RDRAND rng;
        const auto bytesBuffer = new byte[bytesSize];
        rng.GenerateBlock(bytesBuffer, bytesSize);

        std::string base64EncodedBytes;
        CryptoPP::Base64Encoder encoder{ new CryptoPP::StringSink(base64EncodedBytes), false };
        encoder.Put(bytesBuffer, bytesSize);
        encoder.MessageEnd();

        delete bytesBuffer;
        lua_pushlstring(L, base64EncodedBytes.c_str(), base64EncodedBytes.size());
        return 1;
    }

    int generatekey(lua_State* L)
    {
        
        luaL_trimstack(L, 0);
        const auto bytesBuffer = new byte[CryptoPP::AES::MAX_KEYLENGTH];

        CryptoPP::RDRAND rng;
        rng.GenerateBlock(bytesBuffer, CryptoPP::AES::MAX_KEYLENGTH);

        std::string base64EncodedBytes;
        CryptoPP::Base64Encoder encoder{ new CryptoPP::StringSink(base64EncodedBytes), false };
        encoder.Put(bytesBuffer, CryptoPP::AES::MAX_KEYLENGTH);
        encoder.MessageEnd();

        delete bytesBuffer;
        lua_pushlstring(L, base64EncodedBytes.c_str(), base64EncodedBytes.size());
        return 1;
    }

    int hash(lua_State* L)
    {
        
        luaL_trimstack(L, 2);
        std::string data = luaL_checklstring(L, 1, NULL);
        std::string algo = luaL_checklstring(L, 2, NULL);

        std::transform(algo.begin(), algo.end(), algo.begin(), tolower);

        if (!HashTranslationMap.count(algo))
        {
            luaL_argerror(L, 1, "non-existant hash algorithm");
            return 0;
        }

        const auto ralgo = HashTranslationMap[algo];

        std::string hash;

        if (ralgo == MD5) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::Weak1::MD5>(data);
        }
        else if (ralgo == SHA1) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA1>(data);
        }
        else if (ralgo == SHA224) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA224>(data);
        }
        else if (ralgo == SHA256) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA256>(data);
        }
        else if (ralgo == SHA384) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA384>(data);
        }
        else if (ralgo == SHA512) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA512>(data);
        }
        else if (ralgo == SHA3_224) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_224>(data);
        }
        else if (ralgo == SHA3_256) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_256>(data);
        }
        else if (ralgo == SHA3_384) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_384>(data);
        }
        else if (ralgo == SHA3_512) {
            hash = HelpFunctions::hash_with_algo<CryptoPP::SHA3_512>(data);
        }
        else {
            luaL_argerror(L, 1, "non-existant hash algorithm");
            return 0;
        }

        lua_pushlstring(L, hash.c_str(), hash.size());

        return 1;
    }
    using ModePair = std::pair<std::unique_ptr<CryptoPP::CipherModeBase>, std::unique_ptr<CryptoPP::CipherModeBase> >;

    std::optional<ModePair> getEncryptionDecryptionMode(const std::string& modeName) {
        if (modeName == "cbc") {
            //("Mode:cbc");
            return ModePair{
                std::make_unique<CryptoPP::CBC_Mode<CryptoPP::AES>::Encryption>(),
                std::make_unique<CryptoPP::CBC_Mode<CryptoPP::AES>::Decryption>()
            };
        }
        else if (modeName == "cfb") {
            return ModePair{
                std::make_unique<CryptoPP::CFB_Mode<CryptoPP::AES>::Encryption>(),
                std::make_unique<CryptoPP::CFB_Mode<CryptoPP::AES>::Decryption>()
            };
        }
        else if (modeName == "ofb") {
            return ModePair{
                std::make_unique<CryptoPP::OFB_Mode<CryptoPP::AES>::Encryption>(),
                std::make_unique<CryptoPP::OFB_Mode<CryptoPP::AES>::Decryption>()
            };
        }
        else if (modeName == "ctr") {
            return ModePair{
                std::make_unique<CryptoPP::CTR_Mode<CryptoPP::AES>::Encryption>(),
                std::make_unique<CryptoPP::CTR_Mode<CryptoPP::AES>::Decryption>()
            };
        }
        else if (modeName == "ecb") {
            return ModePair{
                std::make_unique<CryptoPP::ECB_Mode<CryptoPP::AES>::Encryption>(),
                std::make_unique<CryptoPP::ECB_Mode<CryptoPP::AES>::Decryption>()
            };
        }
        else {
            return std::nullopt;
        }
    }

    int encrypt(lua_State* L)
    {
        
        luaL_trimstack(L, 2);
        luaL_checktype(L, 1, LUA_TSTRING);
        luaL_checktype(L, 2, LUA_TSTRING);

        const auto rawDataString = lua_tostring(L, 1);
        lua_pushstring(L, HelpFunctions::b64encode(rawDataString).c_str());
        lua_pushstring(L, "");

        return 2;
    }

    int decrypt(lua_State* L)
    {
        
        luaL_trimstack(L, 4);
        luaL_checktype(L, 1, LUA_TSTRING);
        luaL_checktype(L, 2, LUA_TSTRING);
        luaL_checktype(L, 3, LUA_TSTRING);
        luaL_checktype(L, 4, LUA_TSTRING);

        const auto rawDataString = lua_tostring(L, 1);
        lua_pushstring(L, HelpFunctions::b64decode(rawDataString).c_str());
        return 1;
    }

    int lz4compress(lua_State* L)
    {
        
        size_t len = 0;
        const char* data = luaL_checklstring(L, 1, &len);
        std::string out = HelpFunctions::lz4_compress_block(reinterpret_cast<const uint8_t*>(data), len);
        lua_pushlstring(L, out.data(), out.size());
        return 1;
    }

    int lz4decompress(lua_State* L)
    {
        
        size_t len = 0;
        const char* data = luaL_checklstring(L, 1, &len);
        std::string out;
        if (!HelpFunctions::lz4_decompress_block(reinterpret_cast<const uint8_t*>(data), len, out))
            luaL_error(L, "invalid lz4 data");
        lua_pushlstring(L, out.data(), out.size());
        return 1;
    }

    void RegisterLibrary(lua_State* L)
    {
        

        Utils::AddFunction(L, "base64encode", Crypt::base64encode);
        Utils::AddFunction(L, "base64decode", Crypt::base64decode);

        Utils::AddFunction(L, "base64_encode", Crypt::base64encode);
        Utils::AddFunction(L, "base64_decode", Crypt::base64decode);

        Utils::AddFunction(L, "lz4compress", lz4compress);
        Utils::AddFunction(L, "lz4decompress", lz4decompress);

        lua_newtable(L);
        Utils::AddTableFunction(L, "encode", Crypt::base64encode);
        Utils::AddTableFunction(L, "decode", Crypt::base64decode);
        lua_setfield(L, LUA_GLOBALSINDEX, ("base64"));

        lua_newtable(L);
        Utils::AddTableFunction(L, "base64encode", Crypt::base64encode);
        Utils::AddTableFunction(L, "base64decode", Crypt::base64decode);
        Utils::AddTableFunction(L, "base64_encode", Crypt::base64encode);
        Utils::AddTableFunction(L, "base64_decode", Crypt::base64decode);

        lua_newtable(L);
        Utils::AddTableFunction(L, "encode", Crypt::base64encode);
        Utils::AddTableFunction(L, "decode", Crypt::base64decode);
        lua_setfield(L, -2, ("base64"));

        Utils::AddTableFunction(L, "encrypt", Crypt::encrypt);
        Utils::AddTableFunction(L, "decrypt", Crypt::decrypt);
        Utils::AddTableFunction(L, "generatebytes", Crypt::generatebytes);
        Utils::AddTableFunction(L, "generatekey", Crypt::generatekey);
        Utils::AddTableFunction(L, "hash", Crypt::hash);
        Utils::AddTableFunction(L, "lz4compress", Crypt::lz4compress);
        Utils::AddTableFunction(L, "lz4decompress", Crypt::lz4decompress);

        Utils::AddTableFunction(L, "base64encode", Crypt::base64encode);
        Utils::AddTableFunction(L, "base64decode", Crypt::base64decode);
        Utils::AddTableFunction(L, "base64_encode", Crypt::base64encode);
        Utils::AddTableFunction(L, "base64_decode", Crypt::base64decode);

        lua_setfield(L, LUA_GLOBALSINDEX, ("crypt"));
    }
}