#pragma once

#include <lgc.h>
#include <lstate.h>
#include <lualib.h>
#include <string>
#include <vector>

#include <Roblox/Shared/Shared.hpp>
#include <ltable.h>

static LuaTable* RenvCache = nullptr;
static lua_State* RenvCacheState = nullptr;

namespace Miscellaneous
{
    namespace
    {
        inline bool DecodeCompressedBytecode(const std::string& compressed, std::string& output)
        {
            output.clear();

            if (compressed.size() < 8)
                return false;

            std::vector<uint8_t> data(compressed.begin(), compressed.end());
            uint8_t key[4] = {
                static_cast<uint8_t>(data[0] ^ 0x52),
                static_cast<uint8_t>((data[1] ^ 0x53) - 41),
                static_cast<uint8_t>((data[2] ^ 0x42) - 82),
                static_cast<uint8_t>((data[3] ^ 0x31) - 123),
            };

            for (size_t i = 0; i < data.size(); ++i)
                data[i] ^= static_cast<uint8_t>(key[i & 3] + 41 * i);

            uint32_t expectedHash = uint32_t(key[0]) | (uint32_t(key[1]) << 8) | (uint32_t(key[2]) << 16) | (uint32_t(key[3]) << 24);
            uint32_t actualHash = XXH32(data.data(), data.size(), 42);
            if (actualHash != expectedHash)
                return false;

            uint32_t decompressedSize =
                uint32_t(data[4]) | (uint32_t(data[5]) << 8) | (uint32_t(data[6]) << 16) | (uint32_t(data[7]) << 24);
            if (decompressedSize == 0 || decompressedSize > 64 * 1024 * 1024)
                return false;

            output.resize(decompressedSize);
            size_t result = ZSTD_decompress(output.data(), output.size(), data.data() + 8, data.size() - 8);
            if (ZSTD_isError(result))
            {
                output.clear();
                return false;
            }

            output.resize(result);
            return true;
        }
    }

    int getgenv(lua_State* L)
    {
    
        if (Shared::AnetiaState == L)
        {
            lua_pushvalue(L, LUA_GLOBALSINDEX);
            return 1;
        }

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);
        luaC_threadbarrier(Shared::AnetiaState);
        lua_pushvalue(Shared::AnetiaState, LUA_GLOBALSINDEX);
        lua_xmove(Shared::AnetiaState, L, 1);

        return 1;
    }

    int getrenv(lua_State* L)
    {
    
        lua_State* RobloxState = L->global->mainthread;

        if (RenvCacheState != RobloxState)
        {
            RenvCache = nullptr;
            RenvCacheState = RobloxState;
        }

        if (!RenvCache)
        {
            LuaTable* clone = luaH_clone(L, RobloxState->gt);

            lua_rawcheckstack(L, 2);
            luaC_threadbarrier(L);
            luaC_threadbarrier(RobloxState);
            L->top->value.p = clone;
            L->top->tt = LUA_TTABLE;
            L->top++;

            lua_pushvalue(L, -1);
            lua_ref(L, -1);
            lua_pop(L, 1);

            lua_rawgeti(L, LUA_REGISTRYINDEX, 2);
            lua_setfield(L, -2, "_G");
            lua_rawgeti(L, LUA_REGISTRYINDEX, 4);
            lua_setfield(L, -2, "shared");

            RenvCache = clone;
            lua_pop(L, 1);
        }

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);
        L->top->value.p = RenvCache;
        L->top->tt = LUA_TTABLE;
        L->top++;

        return 1;
    }

    int identifyexecutor(lua_State* L)
    {
    
        lua_pushstring(L, "Anetia");
        lua_pushstring(L, "1.0");

        return 2;
    };

    int getexecutorname(lua_State* L)
    {
    
        lua_pushstring(L, "Anetia");

        return 1;
    };

    int getobjects(lua_State* L)
    {
    
        luaL_checktype(L, 1, LUA_TUSERDATA);
        luaL_checktype(L, 2, LUA_TSTRING);

        lua_getglobal(L, "game");
        lua_getfield(L, -1, "GetService");
        lua_pushvalue(L, -2);
        lua_pushstring(L, "InsertService");
        lua_call(L, 2, 1);
        lua_remove(L, -2);

        lua_getfield(L, -1, "LoadLocalAsset");

        lua_pushvalue(L, -2);
        lua_pushvalue(L, 2);
        lua_pcall(L, 2, 1, NULL);

        if (lua_type(L, -1) == LUA_TSTRING)
            luaL_error(L, lua_tostring(L, -1));

        lua_createtable(L, 1, NULL);
        lua_pushvalue(L, -2);
        lua_rawseti(L, -2, 1);

        lua_remove(L, -3);
        lua_remove(L, -2);

        return 1;
    }

    int getreg(lua_State* L)
    {
        
        luaL_trimstack(L, (int)0);

        lua_rawcheckstack(L, 1);
        luaC_threadbarrier(L);

        lua_pushvalue(L, LUA_REGISTRYINDEX);
        return 1;
    }

    int getmenv(lua_State* L)
    {
        
        if (!lua_isuserdata(L, 1)) {
            lua_pushnil(L);
            return 1;
        }

        lua_getfield(L, 1, "ClassName");
        const char* cn = lua_isstring(L, -1) ? lua_tostring(L, -1) : nullptr;
        lua_pop(L, 1);

        if (!cn || strcmp(cn, "ModuleScript") != 0) {
            lua_pushnil(L);
            return 1;
        }

        lua_getglobal(L, "require");
        if (!lua_isfunction(L, -1)) {
            lua_pop(L, 1);
            lua_pushnil(L);
            return 1;
        }

        lua_pushvalue(L, 1);
        if (lua_pcall(L, 1, 1, 0) != 0) {
            lua_pop(L, 1);
            lua_pushnil(L);
            return 1;
        }

        lua_getfenv(L, -1);
        if (lua_istable(L, -1)) {
            lua_remove(L, -2);
            return 1;
        }

        lua_pop(L, 2);
        lua_pushnil(L);
        return 1;
    }

    int checkcaller(lua_State* L) {
        
        if (Shared::AnetiaState && L == Shared::AnetiaState) {
            lua_pushboolean(L, true);
            return 1;
        }
        if (L && L->userdata &&
            (L->userdata->source.expired() ||
                L->userdata->capabilities == MaxCapabilities)) {
            lua_pushboolean(L, true);
            return 1;
        }
        lua_Debug ar;
        for (int level = 1; level <= 10; level++) {
            if (!lua_getinfo(L, level, "f", &ar))
                break;
            if (lua_isfunction(L, -1)) {
                Closure* cl = clvalue(index2addr(L, -1));
                if (cl->isC) {
                    for (auto func : Shared::FunctionVector)
                        if (func == cl || func->c.f == cl->c.f) {
                            lua_pop(L, 1);
                            lua_pushboolean(L, true);
                            return 1;
                        }
                }
                else if (cl->l.p && cl->l.p->source) {
                    const char* src = getstr(cl->l.p->source);
                    if (src && (strcmp(src, "=loadstring") == 0 ||
                        strcmp(src, "@Nam") == 0 || strcmp(src, "@Arona") == 0)) {
                        lua_pop(L, 1);
                        lua_pushboolean(L, true);
                        return 1;
                    }
                }
                if (Shared::WrappedClosures.count(cl)) {
                    lua_pop(L, 1);
                    lua_pushboolean(L, true);
                    return 1;
                }
            }
            lua_pop(L, 1);
        }
        lua_pushboolean(L, false);
        return 1;
    }

    int queueonteleport(lua_State* L)
    {
        size_t length = 0;
        const char* code = luaL_checklstring(L, 1, &length);
        std::lock_guard<std::mutex> lock(Shared::TeleportQueueMutex);
        Shared::TeleportQueue.emplace_back(code, length);
        return 0;
    }

    int clearteleportqueue(lua_State*)
    {
        std::lock_guard<std::mutex> lock(Shared::TeleportQueueMutex);
        Shared::TeleportQueue.clear();
        return 0;
    }

    void RegisterLibrary(lua_State* L)
    {
    

        Utils::AddFunction(L, "getgenv", Miscellaneous::getgenv);
        Utils::AddFunction(L, "getglobalenv", Miscellaneous::getgenv);
        Utils::AddFunction(L, "getrenv", Miscellaneous::getrenv);
        Utils::AddFunction(L, "getrobloxenv", Miscellaneous::getrenv);
        Utils::AddFunction(L, "identifyexecutor", Miscellaneous::identifyexecutor);
        Utils::AddFunction(L, "getexecutorname", Miscellaneous::getexecutorname);
        Utils::AddFunction(L, "GetObjects", Miscellaneous::getobjects);
        Utils::AddFunction(L, "getreg", Miscellaneous::getreg);
        Utils::AddFunction(L, "getregistry", Miscellaneous::getreg);
        Utils::AddFunction(L, "getmenv", Miscellaneous::getmenv);
        Utils::AddFunction(L, "getmoduleenv", Miscellaneous::getmenv);

        Utils::AddFunction(L, "queueonteleport", Miscellaneous::queueonteleport);
        Utils::AddFunction(L, "queue_on_teleport", Miscellaneous::queueonteleport);
        Utils::AddFunction(L, "clearteleportqueue", Miscellaneous::clearteleportqueue);
        Utils::AddFunction(L, "clear_teleport_queue", Miscellaneous::clearteleportqueue);
    }
}