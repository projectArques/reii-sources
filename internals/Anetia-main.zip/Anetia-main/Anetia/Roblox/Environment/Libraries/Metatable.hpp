#pragma once

#include <string>
#include <lstate.h>
#include <lualib.h>

#include <Roblox/Shared/Shared.hpp>
#include <Roblox/Hyperion/Execution/Execution.hpp>
#include <Roblox/Hyperion/TaskScheduler/TaskScheduler.hpp>

namespace Metatable
{
    int getidentity(lua_State* L)
    {
        
        lua_pushinteger(L, L->userdata->identity);
        return 1;
    }

    int setidentity(lua_State* L)
    {
        
        luaL_checktype(L, 1, LUA_TNUMBER);
        int identity = (int)lua_tointeger(L, 1);

        if (!L->userdata)
            return 0;

        uint64_t caps = 0xFFFFFFFFFFFFFF00 | Hyperion::GetCapabilities(&identity);

        if (identity == 8)
        {
            caps = MaxCapabilities;
        }

        L->userdata->identity = identity;
        L->userdata->capabilities = caps;

        const uintptr_t identity_ptr = Hyperion::GetIdentityStruct(*reinterpret_cast<uintptr_t*>(Offsets::Identity::Identity));

        if (identity_ptr) {
            *reinterpret_cast<uint64_t*>(identity_ptr) = identity;
            *reinterpret_cast<uint64_t*>(identity_ptr + Offsets::Capabilities::Capabilities) = caps;
        }

        return 0;
    }

    int setreadonly(lua_State* L)
    {
        
        luaL_checktype(L, 1, LUA_TTABLE);
        luaL_checktype(L, 2, LUA_TBOOLEAN);

        hvalue(luaA_toobject(L, 1))->readonly = lua_toboolean(L, 2);

        return 0;
    }

    int isreadonly(lua_State* L)
    {
        
        luaL_checktype(L, 1, LUA_TTABLE);

        lua_pushboolean(L, hvalue(luaA_toobject(L, 1))->readonly);

        return 1;
    }

    int getrawmetatable(lua_State* L)
    {
        
        lua_normalisestack(L, 1);
        luaL_checkany(L, 1);

        if (!lua_getmetatable(L, 1))
            lua_pushnil(L);

        return 1;
    }

    int setrawmetatable(lua_State* L)
    {
        
        luaL_checkany(L, 1);
        luaL_checktype(L, 2, LUA_TTABLE);
        lua_setmetatable(L, 1);
        lua_pushvalue(L, 1);
        return 1;
    }

    int getnamecallmethod(lua_State* L)
    {
        
        const char* namecall = lua_namecallatom(L, nullptr);

        if (!namecall)
        {
            lua_pushnil(L);
            return 1;
        }

        lua_pushstring(L, namecall);
        return 1;
    }

    int setnamecallmethod(lua_State* L)
    {
        
        lua_normalisestack(L, 1);
        luaL_checktype(L, 1, LUA_TSTRING);

        L->namecall = tsvalue(luaA_toobject(L, 1));

        return 0;
    }

    int isuntouched(lua_State* L)
    {
        
        lua_normalisestack(L, 1);

        luaL_checktype(L, 1, LUA_TTABLE);

        lua_rawcheckstack(L, 1);

        lua_pushboolean(L, static_cast<const LuaTable*>(lua_topointer(L, 1))->safeenv);
        return 1;
    }

    int setuntouched(lua_State* L)
    {
        
        lua_normalisestack(L, 2);

        luaL_checkany(L, 1);
        luaL_checktype(L, 2, LUA_TBOOLEAN);

        luaL_argexpected(L, lua_istable(L, 1) || lua_isthread(L, 1) || lua_isfunction(L, 1), 1, ("table, thread or function"));

        bool is_untouched = lua_toboolean(L, 2);

        if (lua_istable(L, 1)) {
            LuaTable* tbl = hvalue(index2addr(L, 1));
            tbl->safeenv = is_untouched;
        }
        else if (lua_isthread(L, 1)) {
            const lua_State* thread = lua_tothread(L, 1);
            luaL_argexpected(L, thread, 1, ("thread"));

            thread->gt->safeenv = is_untouched;
        }
        else if (lua_isfunction(L, 1)) {
            const Closure* closure = clvalue(index2addr(L, 1));

            closure->env->safeenv = is_untouched;
        }

        return 0;
    }

    int make_writeable(lua_State* L)
    {
        
        lua_normalisestack(L, 1);
        luaL_checktype(L, 1, LUA_TTABLE);

        lua_setreadonly(L, 1, false);

        return 0;
    }

    int make_readonly(lua_State* L)
    {
        
        lua_normalisestack(L, 1);
        luaL_checktype(L, 1, LUA_TTABLE);

        lua_setreadonly(L, 1, true);

        return 0;
    }

    inline int hookmetamethod(lua_State* L)
    {
        luaL_checkany(L, 1);
        luaL_checktype(L, 2, LUA_TSTRING);
        luaL_checktype(L, 3, LUA_TFUNCTION);

        const char* metamethod = lua_tostring(L, 2);

        if (!lua_getmetatable(L, 1)) {
            luaL_argerror(L, 1, "object has no metatable");
        }
        int mt_idx = lua_gettop(L);

        bool wasReadonly = lua_getreadonly(L, mt_idx);
        if (wasReadonly) {
            lua_setreadonly(L, mt_idx, false);
        }

        lua_getfield(L, mt_idx, metamethod);
        if (lua_isnil(L, -1)) {
            lua_pop(L, 1);
            if (wasReadonly) lua_setreadonly(L, mt_idx, true);
            luaL_argerror(L, 2, "metamethod does not exist");
        }
        int old_method = lua_gettop(L);

        lua_pushvalue(L, 3);
        lua_setfield(L, mt_idx, metamethod);

        if (wasReadonly) {
            lua_setreadonly(L, mt_idx, true);
        }

        lua_pushvalue(L, old_method);
        return 1;
    }

    void RegisterLibrary(lua_State* L)
    {
        
        Utils::AddFunction(L, "getidentity", getidentity);
        Utils::AddFunction(L, "getthreadidentity", getidentity);
        Utils::AddFunction(L, "getthreadcontext", getidentity);

        Utils::AddFunction(L, "setidentity", setidentity);
        Utils::AddFunction(L, "setthreadidentity", setidentity);
        Utils::AddFunction(L, "setthreadcontext", setidentity);

        Utils::AddFunction(L, "setreadonly", setreadonly);
        Utils::AddFunction(L, "isreadonly", isreadonly);

        Utils::AddFunction(L, "makewriteable", make_writeable);
        Utils::AddFunction(L, "make_writeable", make_writeable);

        Utils::AddFunction(L, "makereadonly", make_readonly);
        Utils::AddFunction(L, "make_readonly", make_readonly);

        Utils::AddFunction(L, "setuntouched", setuntouched);
        Utils::AddFunction(L, "isuntouched", isuntouched);

        Utils::AddFunction(L, "getnamecallmethod", getnamecallmethod);
        Utils::AddFunction(L, "setnamecallmethod", setnamecallmethod);

        Utils::AddFunction(L, "getrawmetatable", getrawmetatable);
        Utils::AddFunction(L, "setrawmetatable", setrawmetatable);

        Utils::AddFunction(L, "hookmetamethod", hookmetamethod);
    }
}