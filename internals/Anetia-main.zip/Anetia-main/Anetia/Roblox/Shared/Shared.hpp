﻿#pragma once

#include <atomic>

#include <Windows.h>
#include <lua.h>
#include <queue>
#include <functional>
#include <filesystem>
#include <zstd.h>
#include <xxhash.h>
#include <lualib.h>
#include <mutex>
#include <Dependencies/Luau/VM/src/lgc.h>
#include <Dependencies/Luau/VM/src/lmem.h>
#include <unordered_set>
#include <Dependencies/Luau/VM/src/lapi.h>
#include <map>
#include <others/imgui_notify.h>

#define lua_normalisestack(L, mxs) { if (lua_gettop(L) > mxs) lua_settop(L, mxs); }
#define luaL_trimstack(L, n) int top = lua_gettop(L); if (top > n || top < 0) lua_settop(L, n)
#define lua_pushoclosure(L, C) setclvalue(L, L->top, C); incr_top(L)
#define lua_toclosure(L, i) (Closure*)lua_topointer(L, i)

inline uintptr_t MaxCapabilities = 0xFFFFFFFFFFFFFFFF;

namespace Shared {
	inline lua_State* AnetiaState;
	inline lua_State* RobloxState;

	inline uintptr_t lastKnownDatamodel = 0;

	inline int RobloxPcallRef = LUA_NOREF;

	inline std::queue<std::function<void()>> YieldQueue;
	inline std::mutex YieldMutex;
	inline std::vector<std::string> ExecutionRequests;
	inline std::mutex ExecutionRequestsMutex;
	inline std::vector<std::string> TeleportQueue;
	inline std::mutex TeleportQueueMutex;

	inline std::map<Closure*, Closure*> newcclosure_map;
	inline std::map<Closure*, Closure*> hooks_map;
	inline static std::unordered_set<Closure*> WrappedClosures;
	inline static std::unordered_set<Closure*> ExecutorClosures;
	inline std::vector<Closure*> FunctionVector;

	inline bool isInitializedOnGame = false;
	inline bool lockedStep = true;
	inline uintptr_t lastWHSJ = 0;
	inline void* ourVFtable = 0;

	using JobStep_t = uintptr_t(__fastcall*)(uintptr_t Job, uintptr_t Stats);
	inline JobStep_t originalStepFunction = nullptr;

	inline std::filesystem::path workspace_folder;
    inline std::filesystem::path autoexecute_folder;

}

namespace Utils {
    inline std::unordered_map<Closure*, std::pair<lua_CFunction, const char*>> FunctionWrappers;

    struct FunctionData
    {
        lua_CFunction Function;
        const char* Name;
    };

    inline int FunctionWrapper(lua_State* L)
    {
        FunctionData* Data = static_cast<FunctionData*>(
            lua_touserdata(L, lua_upvalueindex(1))
            );

        if (!Data || !Data->Function)
            return 0;

        OutputDebugStringA(Data->Name);

        return Data->Function(L);
    }

    inline void AddFunction(lua_State* L, const char* Name, lua_CFunction Function)
    {
        FunctionData* Data = new FunctionData{ Function, Name };

        lua_pushlightuserdata(L, Data);
        lua_pushcclosure(L, FunctionWrapper, Name, 1);

        Closure* funcclosure = clvalue(luaA_toobject(L, -1));
        Shared::FunctionVector.push_back(funcclosure);

        lua_setglobal(L, Name);
    }

    inline void AddTableFunction(lua_State* L, const char* Name, lua_CFunction Function)
    {
        FunctionData* Data = new FunctionData{ Function, Name };

        lua_pushlightuserdata(L, Data);
        lua_pushcclosure(L, FunctionWrapper, Name, 1);

        Closure* funcclosure = clvalue(luaA_toobject(L, -1));
        Shared::FunctionVector.push_back(funcclosure);

        lua_setfield(L, -2, Name);
    }

    inline bool CheckMemory(uintptr_t address) {
        if (address < 0x10000 || address > 0x7FFFFFFFFFFF) {
            return false;
        }

        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQuery(reinterpret_cast<void*>(address), &mbi, sizeof(mbi)) == 0) {
            return false;
        }

        if (mbi.Protect & PAGE_NOACCESS || mbi.State != MEM_COMMIT) {
            return false;
        }

        return true;
    }
}