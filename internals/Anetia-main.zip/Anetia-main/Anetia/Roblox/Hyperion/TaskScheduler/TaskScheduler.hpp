#pragma once

#include <Windows.h>
#include <cstdint>
#include <string>

#include <lualib.h>
#include <lua.h>
#include <Dependencies/Luau/VM/src/lobject.h>
#include <Dependencies/Luau/VM/src/lstate.h>

#include <Dependencies/Luau/Bytecode/include/Luau/BytecodeBuilder.h>
#include <Luau/BytecodeUtils.h>
#include <Luau/Compiler.h>

#include <Roblox/Hyperion/Execution/Execution.hpp>
#include <Roblox/Environment/Yielding/Yielding.hpp>
#include <Roblox/Shared/Shared.hpp>

#include <cstring>
#include <vector>

template<typename T>
inline void Write(uintptr_t address, T value, uintptr_t offset = 0)
{
	*reinterpret_cast<T*>(address + offset) = value;
}

namespace TaskScheduler
{
	uintptr_t GetDatamodel();
	uintptr_t GetScriptContext(uintptr_t Datamodel);
	int64_t GetLuaState(uintptr_t ScriptContext);

	int GetGameLoaded(uintptr_t Datamodel);
	uintptr_t GetJobByName(const std::string& Name);
	uintptr_t GetJobByTypeName(const std::string& TypeName);

	void SetProtoCapabilities(Proto* proto, uintptr_t* capabilities);
	void SetThreadCapabilities(lua_State* L, int Level, uintptr_t Capabilities);
	void SetIdentity(lua_State* Thread, int Identity, bool IsInstance);

	void SendScript(const std::string& Script);
}