#pragma once

#include <Windows.h>
#include <cstdint>
#include <string>

#include <Roblox/Hyperion/Scheduler/Communication/Communication.hpp>
#include <Roblox/Hyperion/TaskScheduler/TaskScheduler.hpp>
namespace Scheduler
{
    void Reset();
    void TeleportHandler();
}