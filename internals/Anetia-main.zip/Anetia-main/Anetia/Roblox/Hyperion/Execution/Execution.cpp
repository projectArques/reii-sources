#include <Roblox/Shared/Shared.hpp>
#include <Roblox/Hyperion/Execution/Execution.hpp>
#include <Roblox/Hyperion/TaskScheduler/TaskScheduler.hpp>

class BytecodeEncoder : public Luau::BytecodeEncoder
{
	inline void encode(uint32_t* data, size_t count) override
	{
		for (auto i = 0; i < count;)
		{
			uint8_t Opcode = LUAU_INSN_OP(data[i]);
			const auto LookupTable = reinterpret_cast<BYTE*>(Offsets::OpcodeLookupTable);
			uint8_t FinalOpcode = Opcode * 227;
			FinalOpcode = LookupTable[FinalOpcode];

			data[i] = (FinalOpcode) | (data[i] & ~0xFF);
			i += Luau::getOpLength(static_cast<LuauOpcode>(Opcode));
		}
	}
};

std::string Execution::CompileScript(std::string Source)
{
	auto BytecodeEncoding = BytecodeEncoder();
	static const char* CommonGlobals[] = { "Game", "Workspace", "game", "plugin", "script", "shared", "workspace", "_G", "_ENV", nullptr };

	Luau::CompileOptions Options;
	Options.debugLevel = 2;
	Options.optimizationLevel = 1;
	Options.mutableGlobals = CommonGlobals;
	Options.vectorLib = "Vector3";
	Options.vectorCtor = "new";
	Options.vectorType = "Vector3";

	return Luau::compile(Source, Options, {}, &BytecodeEncoding);
}

void Execution::ExecuteScript(lua_State* L, std::string Script)
{
	if (!L || Script.empty())
		return;

	int OriginalTop = lua_gettop(L);
	lua_State* ExecutionThread = lua_newthread(L);
	lua_pop(L, 1);

	luaL_sandboxthread(ExecutionThread);
	TaskScheduler::SetThreadCapabilities(ExecutionThread, 8, MaxCapabilities);

	std::string Bytecode = Execution::CompileScript(Script);
	if (luau_load(ExecutionThread, "", Bytecode.c_str(), Bytecode.length(), NULL) != LUA_OK)
	{
		std::string Error = lua_tostring(ExecutionThread, -1);
		ImGui::InsertNotification({ ImGuiToastType_Error, 5000, "%s", Error.c_str() });
		lua_pop(ExecutionThread, 1);
		return;
	}

	Closure* Closure = clvalue(luaA_toobject(ExecutionThread, -1));
	TaskScheduler::SetProtoCapabilities(Closure->l.p, &MaxCapabilities);

	lua_getglobal(ExecutionThread, "task");
	lua_getfield(ExecutionThread, -1, "defer");
	lua_remove(ExecutionThread, -2);
	lua_insert(ExecutionThread, -2);

	if (lua_pcall(ExecutionThread, 1, NULL, NULL) != LUA_OK)
	{
		std::string Error = lua_tostring(ExecutionThread, -1);
		ImGui::InsertNotification({ ImGuiToastType_Error, 5000, "%s", Error.c_str() });
		lua_pop(ExecutionThread, 1);
		return;
	}

	lua_settop(L, OriginalTop);
}