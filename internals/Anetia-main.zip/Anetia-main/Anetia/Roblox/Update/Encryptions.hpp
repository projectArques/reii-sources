#pragma once

#include <Windows.h>

template<typename T>
struct vmvalue1
{
private:
    T Storage;

public:
    operator const T() const
    {
        return (T)((uintptr_t)Storage - (uintptr_t)this);
    }

    void operator=(const T& Value)
    {
        Storage = (T)((uintptr_t)Value + (uintptr_t)this);
    }

    const T operator->() const
    {
        return operator const T();
    }

    T Get() const
    {
        return operator const T();
    }

    void Set(const T& Value)
    {
        operator=(Value);
    }
};

template<typename T>
struct vmvalue2
{
private:
    T Storage;

public:
    operator const T() const
    {
        return (T)((uintptr_t)this - (uintptr_t)Storage);
    }

    void operator=(const T& Value)
    {
        Storage = (T)((uintptr_t)this - (uintptr_t)Value);
    }

    const T operator->() const
    {
        return operator const T();
    }

    T Get() const
    {
        return operator const T();
    }

    void Set(const T& Value)
    {
        operator=(Value);
    }
};

template<typename T>
struct vmvalue3
{
private:
    T Storage;

public:
    operator const T() const
    {
        return (T)((uintptr_t)this ^ (uintptr_t)Storage);
    }

    void operator=(const T& Value)
    {
        Storage = (T)((uintptr_t)Value ^ (uintptr_t)this);
    }

    const T operator->() const
    {
        return operator const T();
    }

    T Get() const
    {
        return operator const T();
    }

    void Set(const T& Value)
    {
        operator=(Value);
    }
};

template<typename T>
struct vmvalue4
{
private:
    T Storage;

public:
    operator const T() const
    {
        return (T)((uintptr_t)this + (uintptr_t)Storage);
    }

    void operator=(const T& Value)
    {
        Storage = (T)((uintptr_t)Value - (uintptr_t)this);
    }

    const T operator->() const
    {
        return operator const T();
    }

    T Get() const
    {
        return operator const T();
    }

    void Set(const T& Value)
    {
        operator=(Value);
    }
};

#define proto_lineinfo     vmvalue3 // proto_lineinfo_enc
#define proto_debuginsn    vmvalue2 // proto_debuginsn_enc
#define proto_typeinfo     vmvalue1 // proto_typeinfo_enc
#define proto_abslineinfo  vmvalue4 // proto_abslineinfo_enc
#define proto_source       vmvalue1 // proto_source_enc
#define proto_locvars      vmvalue1 // proto_locvars_enc
#define proto_upvalues     vmvalue1 // proto_upvalues_enc
#define proto_debugname    vmvalue4 // proto_debugname_enc
#define proto_userdata     vmvalue4 // proto_userdata_enc
#define udata_meta         vmvalue3 // udata_meta_enc
#define closure_debugname  vmvalue1 // closure_debugname_enc
#define closure_cont       vmvalue3 // closure_cont_enc
#define tstring_hash       vmvalue3 // tstring_hash_enc
#define lstate_stacksize   vmvalue4 // lstate_stacksize_enc