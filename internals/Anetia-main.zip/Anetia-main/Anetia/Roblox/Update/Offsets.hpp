#pragma once

#include <lua.h>
#include <Windows.h>
#include <cstdint>
#include <memory>

#define Rebase(Address) (Address + reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr)))

struct lua_State;
struct YieldState;
struct YieldingLuaThread;

namespace Offsets 
{
    const uintptr_t OpcodeLookupTable = Rebase(0x6B83740);

    namespace Luau
    {
        const uintptr_t LuaO_NilObject = Rebase(0x610EFF8);
        const uintptr_t LuaH_DummyNode = Rebase(0x610EEB8);
        const uintptr_t LuaD_Throw = Rebase(0xB40C30);
        const uintptr_t Luau_Execute = Rebase(0xB59570);
        const uintptr_t LuaVM_Load = Rebase(0x223D370);
    }

    namespace DataModel
    {
        const uintptr_t ScriptContext = 0x440;
        const uintptr_t Children = 0x78;
        const uintptr_t GameLoaded = 0x570;
        const uintptr_t ClassDescriptor = 0x18;

        const uintptr_t FakeDataModelToDataModel = 0x1D8;
        const uintptr_t FakeDataModelPointer = Rebase(0x8b79b58);
    }

    namespace ExtraSpace
    {
        const uintptr_t ScriptContextResume = Rebase(0x22BBA10);
        const uintptr_t ScriptContextToResume = 0x7E0;
    }

    namespace Identity
    {
        const uintptr_t Identity = Rebase(0x7EEB448);
        const uintptr_t GetIdentityStruct = Rebase(0x4170);
    }

    namespace Capabilities
    {
        const uintptr_t GetCapabilities = Rebase(0x8F7FD0);
        const uintptr_t Capabilities = 0x28;
    }

    namespace Scripts
    {
        const uintptr_t LocalScriptByteCode = 0x190;
        const uintptr_t ModuleScriptByteCode = 0x138;
        const uintptr_t BytecodeStringOffset = 0x18;
        const uintptr_t ServerContextFlag = 0x130;

        const uintptr_t Pointer = 0x10;
        const uintptr_t Size = 0x20;
    }

    namespace InstanceBridge
    {
        const uintptr_t Push = Rebase(0x222A6B0);
    }

    namespace TaskScheduler
    {
        const uintptr_t TaskSchedulerPtr = Rebase(0x88B64C8); // TODO: fill in TaskScheduler pointer
        const uintptr_t JobStart = 0xC8;
        const uintptr_t JobName = 0x18;
    }

    namespace Renderer
    {
        const uintptr_t ViewBase = 0x1d8;
        const uintptr_t Device = 0x8;
        const uintptr_t SwapChain = 0xC8;
    }

    namespace ScriptContext 
    {
        const uintptr_t RequireBypass = 0x898;
    }

    namespace Raknet
    {
        const uintptr_t RakPeer = 0x1D8;
    }
}

namespace Hyperion 
{

    inline auto LuaVM_Load = (int(__fastcall*)(lua_State * thread, void* bytecode, const char* chunkName, int env))Offsets::Luau::LuaVM_Load;
    inline auto Luau_Execute = (void(__fastcall*)(lua_State*))Offsets::Luau::Luau_Execute;

    inline auto ScriptContextResume = (uint64_t(__fastcall*)(uint64_t, YieldState*, YieldingLuaThread**, uint32_t, uint8_t, uint64_t))Offsets::ExtraSpace::ScriptContextResume;
    inline auto LuaD_Throw = (void(__fastcall*)(lua_State*, int))Offsets::Luau::LuaD_Throw;
    inline auto GetIdentityStruct = (uintptr_t(__fastcall*)(uintptr_t))Offsets::Identity::GetIdentityStruct;
    inline auto GetCapabilities = (__int64(__fastcall*)(int*))Offsets::Capabilities::GetCapabilities;

    namespace InstanceBridge
    {
        inline auto UintPtr = (void(__fastcall*)(lua_State*, std::uintptr_t))Offsets::InstanceBridge::Push;
        inline auto Shared = (void(__fastcall*)(lua_State*, std::shared_ptr<std::uintptr_t*>))Offsets::InstanceBridge::Push;
        inline auto Void = (void(__fastcall*)(lua_State*, void**))Offsets::InstanceBridge::Push;
        inline auto Void2 = (void(__fastcall*)(lua_State*, void*))Offsets::InstanceBridge::Push;
        inline auto Weak = (void(__fastcall*)(lua_State*, std::weak_ptr<std::uintptr_t>))Offsets::InstanceBridge::Push;
    }
}