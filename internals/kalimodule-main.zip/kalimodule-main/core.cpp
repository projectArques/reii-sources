﻿#include "Proxy.h"
#include "includes.h"
#include <communication/communication.h>
#include <manager/manager.h>
#include <manager/render/render.h>
#include <thread>
#include <chrono>
#include <manager/render/other/structures.h>

inline std::atomic<bool> rendering { true };

inline void setup()
{    
    using std::chrono::milliseconds;
    using std::this_thread::sleep_for;

    render_manager::instance();
    communication::init();

    while (true)
    {
        sleep_for(milliseconds(1000));

        const uintptr_t datamodel = scheduler::get_datamodel();
        
        if (!datamodel || (includes::last_dm != datamodel && !manager::instance()->is_in_game(datamodel)))
        {
            jobs::unhook_all_jobs();
            manager::instance()->drawing_cleanup();
            includes::last_dm = 0;
            continue;
        }

        if (includes::last_dm != datamodel)
        {
            jobs::unhook_all_jobs();
            includes::execution_rq.clear();
            manager::instance()->drawing_cleanup();
            includes::last_dm = datamodel;

            scheduler::init();
            rendering.store(true);
        }

        if (!jobs::is_job_hooked(obf_("WaitingHybridScriptsJob")))
            jobs::hook_job(obf_("WaitingHybridScriptsJob"));
    }
}

extern "C" __declspec(dllexport) LRESULT CALLBACK Signal(int code, WPARAM wParam, LPARAM lParam)
{
    return CallNextHookEx(NULL, code, wParam, lParam);
    // для инжектора
    // (функция nexthook тоже подходит)
}
BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {  
        DisableThreadLibraryCalls(module);
        std::thread(setup).detach();
    }
    return TRUE;
}

extern "C" __declspec(dllexport) int NextHook(int nCode, WPARAM wParam, LPARAM lParam) { return CallNextHookEx(NULL, nCode, wParam, lParam); }