# Модуль на 84% sUNC сделанный для кал екзекьютор без бусификации

<div align="center">    

<img width="2335" height="1291" alt="Без названия32_20260907165424" src="https://github.com/user-attachments/assets/e09bff8f-c5eb-4360-bfe9-371a55e6f36c" />

</div>

--- 

# Thanks skidleaks for publishing me

---

Некоторые функции могли отвалиться из за апдейтов, так как сам модуль это база слитой дллки с мая, а я лишь обновил ее на ласт версию роблокса и доработал, добавив некоторые функции.

Если у вас есть вопросы, пишите @codecvt в телеграм/дискорд.

ДЛЯ УСПЕШНОЙ СБОРКИ МОДУЛЯ НУЖНО ЗАКИНУТЬ ФАЙЛ cryptopp.lib в папку dependencies\cryptopp\lib

[Скачать cryptopp.lib](https://github.com/jealleal/kalimodule/releases/download/read/cryptopp.lib)

### Credits
* MODULE BY .danlacho
* https://github.com/luwu-community/luwu
* https://github.com/7GrandDadPGN/VapeV4ForRoblox
* https://github.com/RavageDevs/SkidBase
* https://github.com/ocornut/imgui/
* https://nothings.org/stb/
* https://github.com/bestkakkoii/SaSH
* https://github.com/r-lyeh-archived/sole
* https://github.com/machinezone/IXWebSocket
* https://github.com/lz4/lz4
* https://github.com/Mbed-TLS/mbedtls
* https://github.com/Mbed-TLS/TF-PSA-Crypto
* https://github.com/facebook/zstd
* https://github.com/itzmeanjan/turboshake
* https://github.com/weidai11/cryptopp
