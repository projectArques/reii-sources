#include <Windows.h>
#include "instance.h"
#include <thread>

#include "hook.h"
#include "script.h"
#include "console.h"


void* a(uintptr_t addr) {
    return reinterpret_cast<void*>(addr);
}
void _sleep_(int ms) {
    std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}


DWORD WINAPI dsi_lusion___is_cool(void* param)
{
    mem->attach();

    globals::base = mem->get_process_base();
    internal::print(0LL, "base addr: 0x%p", a(globals::base)); _sleep_(100);

    auto fakedm = mem->read<o>(offsets::datamodel::fakedm_pointer);
    globals::datamodel = mem->read<o>(fakedm + offsets::datamodel::real_datamodel);
    internal::print(0LL, "datamodel addr: 0x%p", a(globals::datamodel));_sleep_(100);

    globals::task_scheduler = mem->read<o>(offsets::task_scheduler::pointer);
    internal::print(0LL, "task_scheduler addr: 0x%p", a(globals::task_scheduler));

    bool ok = hook::hook_job("WaitingHybridScriptsJob", 3);

    execution::initialize(); _sleep_(100);

    execution::add_script("while true do printidentity(); task.wait(1) end");


    MessageBoxA(NULL, "", "", 0x0);

    /*
    Console::RConsoleCreate();
    while (true)
    {
        std::string text = Console::RConsoleInput();
        internal::print(0, text.c_str());
        if (!text.empty()) { execution::add_script(text); }
    } */

    ok ? internal::print(0, "[c] success") : internal::print(3, "[c] failed");

    return ok;
}


BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    if (ul_reason_for_call == DLL_PROCESS_ATTACH) {
        std::thread(dsi_lusion___is_cool, hModule).detach();
    }

    return TRUE;
}

