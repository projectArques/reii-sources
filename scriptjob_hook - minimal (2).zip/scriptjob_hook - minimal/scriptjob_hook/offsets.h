#pragma once
#include <cstdint>


inline bool IsValidAddress(uintptr_t addr) {
    static uintptr_t ok = 0x10000; static uintptr_t no = 0x00007FFFFFFEFFFF;
    return addr >= ok && addr <= no;
}

#define REBASE(addr)(addr+reinterpret_cast<uintptr_t>(GetModuleHandleA(nullptr)))
#define MAX_CAPABILITIES 0xFFFFFFFFFFFFFFFF
using o = uintptr_t;

namespace offsets {
    namespace instance {
        inline constexpr o children_end = 0x8;
        inline constexpr o children_start = 0x78;
        inline constexpr o parent = 0x68;
        inline constexpr o class_descriptor = 0x18;
        inline constexpr o class_name = 0x8;

        inline constexpr o name_container = 0x70;
        inline constexpr o name = 0x8;
    }

    namespace task_scheduler {
        inline o pointer = REBASE(0x88B64C8);

        inline constexpr o job_start = 0xc8;
        inline constexpr o job_end = 0xd0;
        inline constexpr o job_name = 0x18;
    }

    namespace datamodel {
        inline o fakedm_pointer = REBASE(0x8B79B58);
        inline constexpr o real_datamodel = 0x1D8;

        inline constexpr o script_context = 0x440;
    }

    namespace player {
        inline constexpr o local_player = 0x130;
        inline constexpr o model_instance = 0x298;
        inline constexpr o player_character = model_instance;
    }

    namespace internal {
        inline o print = REBASE(0x92C340); // 48 89 54 24 ? 4C 89 44 24 ? 4C 89 4C 24 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 48 8B FA
        inline o get_global_state_for_instance = REBASE(0x2219D10); // 48 83 EC ? 8B 81 ? ? ? ? 90 83 F8 ? 7D ? 48 81 C1 ? ? ? ? E8
        inline o luaVM_load = REBASE(0x223D370); // 40 53 56 57 41 54 41 55 41 56 41 57 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 84 24 ? ? ? ? 45 8B E1 44 89 4C 24
        inline o task_defer = REBASE(0x23B5980); // 48 89 5C 24 ? 48 89 74 24 ? 48 89 7C 24 ? 55 41 54 41 55 41 56 41 57 48 8D 6C 24 ? 48 81 EC ? ? ? ? 48 8B 05 ? ? ? ? 48 33 C4 48 89 45 ? 48 8B F9 33 DB 38 1D
    }

    namespace script {

        inline constexpr o localscript_bytecode = 0x190;
        inline constexpr o modulescript_bytecode = 0x138;

        inline constexpr o bytecode_pointer = 0x18;
        inline constexpr o bytecode_size = 0x28;

        inline constexpr o lua_top = 0x18;

    }
}

namespace globals {
    inline o datamodel = 0x0;
    inline o base = 0x0;
    inline o task_scheduler = 0x0;
    inline o lua_state = 0x0;
}

namespace internal {
    using _print = uintptr_t(__fastcall*)(uintptr_t, const char*, ...);
    auto print = (_print)(offsets::internal::print);

    using _get_global_state_for_instance = uintptr_t(__fastcall*)(uintptr_t, uintptr_t*, uintptr_t*);
    auto get_global_state_for_instance = (_get_global_state_for_instance)(offsets::internal::get_global_state_for_instance);

    using _luaVM_load = int(__fastcall*)(uintptr_t, void*, const char*, int);
    auto luaVM_load = (_luaVM_load)(offsets::internal::luaVM_load);

    using _task_defer = uintptr_t(__fastcall*)(uintptr_t);
    auto task_defer = (_task_defer)(offsets::internal::task_defer);
}