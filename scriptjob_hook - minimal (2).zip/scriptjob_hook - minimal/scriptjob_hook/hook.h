#pragma once
#include "instance.h"

#include <unordered_map>
#include <cstring>
#include "script.h"

using job_original_vf = uintptr_t(__fastcall*)(uintptr_t A1, uintptr_t A2, uintptr_t A3);
static job_original_vf original_vf = {};

namespace hook
{

	uintptr_t _jump(uintptr_t A1, uintptr_t A2, uintptr_t A3) {
		if (!globals::lua_state) return original_vf(A1, A2, A3);

		if (!script_queue.empty()) {
			std::string Script = script_queue.front();
			script_queue.erase(script_queue.begin());

			if (!Script.empty())
				execution::execute_script(Script);
		}

		return original_vf(A1, A2, A3);
	}
	
	int hook_job(const std::string& name, int index = 2) {
		uintptr_t Job = instance::get_job_by_name(name);
		if (!Job) return 0;

		void** VTable = new void* [25]();
		memcpy(VTable, *(void**)Job, sizeof(uintptr_t) * 25);

		original_vf = (job_original_vf)VTable[index];
		VTable[index] = _jump;

		*(void**)Job = VTable;
        internal::print(0LL, "HOOKED JOB %s", std::to_string(index));

		return 1;
	}


}