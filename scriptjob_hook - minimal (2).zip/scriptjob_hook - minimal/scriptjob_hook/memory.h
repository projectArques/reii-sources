#pragma once

#pragma region includes

#include <windows.h>
#include <string>
#include <string_view>
#include <vector>
#include <cstdint>
#include <cstring>
#include <psapi.h>
#include <memory>

#pragma endregion

#pragma region classes

class memory {
public:
	memory() = default;
	~memory() = default;

	bool attach();

	HMODULE get_module(std::string_view module_name);

	/* functions */

	template <typename t>
	t read(uintptr_t address);

	template <typename t>
	std::vector<t> read(uintptr_t address, size_t size);

	bool read(uintptr_t address, void* buffer, size_t size);

	template <typename t>
	bool write(uintptr_t address, t value);

	template <typename t>
	bool write(uintptr_t address, const std::vector<t>& bytes);

	bool write(uintptr_t address, std::string_view bytes);

	bool write(uintptr_t address, const void* buffer, size_t size);

	uintptr_t allocate(size_t size);
	uintptr_t allocate(size_t size, ULONG protection);

	bool protect(uintptr_t address, size_t size, ULONG protection);
	bool protect(uintptr_t address, size_t size, ULONG protection, PULONG old_protection);

	bool free(uintptr_t address);

	/* getters */

	DWORD     get_process_id()     const { return process_id; }
	uintptr_t get_process_base()   const { return process_base; }

private:
	DWORD process_id = 0;
	uintptr_t process_base = 0;

	// guards against reading/writing unmapped memory without crashing the host process.
	// SEH is used since in-process reads can legitimately hit bad pointers (same risk
	// ReadProcessMemory silently absorbed for you externally).
	static bool safe_memcpy(void* dst, const void* src, size_t size);
};

#pragma endregion

#pragma region memory definitions

inline bool memory::safe_memcpy(void* dst, const void* src, size_t size) {
	__try {
		memcpy(dst, src, size);
		return true;
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		return false;
	}
}

inline bool memory::attach() {
	this->process_id = GetCurrentProcessId();

	this->process_base = (uintptr_t)GetModuleHandleA(nullptr);

	return this->process_base != 0;
}

inline HMODULE memory::get_module(std::string_view module_name) {
	if (module_name.empty()) return 0;
	return GetModuleHandleA(std::string(module_name).c_str());
}

template <typename t>
inline t memory::read(uintptr_t address) {
	t buffer{};
	if (!safe_memcpy(&buffer, (void*)address, sizeof(t)))
		return t();
	return buffer;
}

template <typename t>
inline std::vector<t> memory::read(uintptr_t address, size_t size) {
	std::vector<t> buffer(size);
	if (!safe_memcpy(buffer.data(), (void*)address, size * sizeof(t)))
		return std::vector<t>();
	return buffer;
}

inline bool memory::read(uintptr_t address, void* buffer, size_t size) {
	return safe_memcpy(buffer, (void*)address, size);
}

template <typename t>
inline bool memory::write(uintptr_t address, t value) {
	return safe_memcpy((void*)address, &value, sizeof(t));
}

template <typename t>
inline bool memory::write(uintptr_t address, const std::vector<t>& bytes) {
	return safe_memcpy((void*)address, bytes.data(), bytes.size() * sizeof(t));
}

inline bool memory::write(uintptr_t address, std::string_view bytes) {
	return safe_memcpy((void*)address, bytes.data(), bytes.size());
}

inline bool memory::write(uintptr_t address, const void* buffer, size_t size) {
	return safe_memcpy((void*)address, buffer, size);
}

inline uintptr_t memory::allocate(size_t size) {
	auto allocated = VirtualAlloc(nullptr, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
	return (uintptr_t)allocated;
}

inline uintptr_t memory::allocate(size_t size, ULONG protection) {
	auto allocated = VirtualAlloc(nullptr, size, MEM_RESERVE | MEM_COMMIT, protection);
	return (uintptr_t)allocated;
}

inline bool memory::protect(uintptr_t address, size_t size, ULONG protection) {
	DWORD old;
	return VirtualProtect((LPVOID)address, size, protection, &old) != 0;
}

inline bool memory::protect(uintptr_t address, size_t size, ULONG protection, PULONG old_protection) {
	return VirtualProtect((LPVOID)address, size, protection, old_protection) != 0;
}

inline bool memory::free(uintptr_t address) {
	return VirtualFree((LPVOID)address, 0, MEM_RELEASE) != 0;
}

#pragma endregion

inline auto mem = std::make_unique<memory>();

// roblox structs
struct Vector3 {
	float x;
	float y;
	float z;
};

struct Vector2 {
	float x;
	float y;
};

struct Color3 {
	unsigned char r;
	unsigned char g;
	unsigned char b;
};

struct CFrame {
	Vector3 RightVector;
	Vector3 UpVector;
	Vector3 LookVector;
	Vector3 Position;
};

struct Child {
	uintptr_t addr;
	uintptr_t control_block;
};