#pragma once

#include <Windows.h>
#include <iostream>
#include <functional>


#include "offsets.h"
#include "memory.h"

class instance {
public:
    // member variables
    uintptr_t address;
    instance(uintptr_t addr) : address(addr) {}
    static bool is_valid(uintptr_t addr) { return addr != 0x0 && addr < 0x00007FFFFFFFFFFF; }
    static bool is_valid(instance& inst) { return is_valid(inst.address); }
    // read string helper functions
    static std::string readstring(std::uint64_t address)
    {
        std::string string;
        char character = 0;
        int char_size = sizeof(character);
        int offset = 0;

        string.reserve(204);

        while (offset < 200)
        {
            character = mem->read<char>(address + offset);

            if (character == 0)
                break;

            offset += char_size;
            string.push_back(character);
        }

        return string;
    }
    static std::string read_string(std::uint64_t string)
    {
        const auto length = mem->read<int>(string + 0x18);

        if (length >= 16u)
        {
            const auto New = mem->read<std::uint64_t>(string);
            return readstring(New);
        }
        else
        {
            const auto Name = readstring(string);
            return Name;
        }
    }

    // roblox instance functions
    std::string get_name()
    {
        if (!is_valid(this->address)) return ("[INVALID]");
        uint64_t name_container = mem->read<uint64_t>(this->address + offsets::instance::name_container);

        std::string name = read_string(name_container + offsets::instance::name);

        return name;
    }

    std::vector<instance> get_children()
    {
        std::vector<instance> children;

        if (!is_valid(this->address)) {
            std::cout << "invalid instance address";
            return {};
        }

        uintptr_t base = mem->read<uintptr_t>(
            this->address + offsets::instance::children_start
        );

        if (!base) {
            // std::cout << "children base is null";
            return {};
        }

        uintptr_t endPtr = mem->read<uintptr_t>(
            base + offsets::instance::children_end
        );

        uintptr_t childArray = mem->read<uintptr_t>(base);

        if (!childArray || !endPtr || childArray >= endPtr) {
            std::cout << "invalid children range";
            return {};
        }

        int count = 0;

        for (uintptr_t it = childArray; it < endPtr; it += 0x10)
        {
            uintptr_t child = mem->read<uintptr_t>(it);

            if (!is_valid(child)) {
                std::cout << "invalid child pointer";
                count++;
                continue;
            }

            instance obj(child);

            children.push_back(obj);
            count++;
        }

        return children;
    }
    std::vector<instance> get_descendants()
    {
        std::vector<instance> descendants;
        std::vector<instance> stack;

        if (!is_valid(this->address))
        {
            std::cout << "invalid instance address";
            return {};
        }

        stack = get_children();

        while (!stack.empty())
        {
            instance current = stack.back();
            stack.pop_back();

            descendants.push_back(current);

            auto children = current.get_children();

            for (auto& child : children)
            {
                stack.push_back(child);
            }
        }

        return descendants;
    }

    instance find_first_child(std::string childName)
    {
        std::vector<instance> children;
        if (!is_valid(this->address)) {
            std::cout << "invalid address in find_first_child: " << (void*)this->address;
            return instance(0x0);
        }

        auto Children = this->get_children();
        for (auto& Child : Children) {
            if (Child.get_name() == childName) return Child;
        }
        return instance(0x0);
    }
    instance get_parent()
    {
        std::vector<instance> children;
        if (!is_valid(this->address)) {
            std::cout << "invalid address in get_parent: " << (void*)this->address;
            return instance(0x0);
        }

        uintptr_t ParentPointer = mem->read<uintptr_t>(this->address + offsets::instance::parent);
        if (ParentPointer)
        {
            instance Parent(ParentPointer);
            return Parent;
        }

        return instance(0x0);
    }

    std::string get_class()
    {
        if (!is_valid(this->address)) {
            std::cout << "invalid address in get_class: " << (void*)this->address;
            return "";
        }

        uintptr_t ClassDescriptor = mem->read<uintptr_t>(this->address + offsets::instance::class_descriptor);

        if (!ClassDescriptor || !is_valid(ClassDescriptor))
            return "";

        uintptr_t ClassNamePTR = mem->read<uintptr_t>(ClassDescriptor + offsets::instance::class_name);

        if (!ClassNamePTR || !is_valid(ClassNamePTR))
            return "";

        std::string result;
        char c;

        while ((c = mem->read<char>(ClassNamePTR++)) != '\0')
            result.push_back(c);

        return result;
    }

    instance get_service(std::string serviceName)
    {
        std::vector<instance> children;
        if (!is_valid(this->address)) {
            std::cout << "invalid address in get_service: " << (void*)this->address;
            return instance(0x0);
        }

        if (!is_valid(globals::datamodel)) {
            std::cout << "invalid datamodel in get_service: " << (void*)globals::datamodel;
            return instance(0x0);
        }

        for (auto& Child : instance(globals::datamodel).get_children())
        {
            if (Child.get_class() == serviceName) return Child;
        }
        return instance(0x0);
    }

    static std::vector<uintptr_t> get_jobs()
    {
        std::vector<uintptr_t> jobs;

        uintptr_t start = mem->read<uintptr_t>(globals::task_scheduler + offsets::task_scheduler::job_start);
        uintptr_t end = mem->read<uintptr_t>(globals::task_scheduler + offsets::task_scheduler::job_end);

        for (auto i = start; i < end; i += 0x10)
        {
            jobs.push_back(mem->read<uintptr_t>(i));
        }

        return jobs;
    }

    static uintptr_t get_job_by_name(std::string name)
    {
        for (auto job : get_jobs())
        {
            std::string jobName = read_string(job + offsets::task_scheduler::job_name);

            if (jobName == name) { return job; }
        }

        return 0;
    }
};
class players : public instance {
public:
    players(uintptr_t addr) : instance(addr) {}
    players(const instance& inst) : instance(inst.address) {}
    instance get_local_player() {
        std::vector<instance> children;
        if (!is_valid(this->address)) {
            std::cout << "invalid address in get_local_player: " << (void*)this->address;
            return instance(0x0);
        }

        instance players = get_service("Players");
        if (!is_valid(players)) {
            std::cout << "invalid players service in get_local_player: " << (void*)players.address;
            return instance(0x0);
        }
        return instance(mem->read<uintptr_t>(players.address + offsets::player::local_player));
    }
    instance get_character() {
        std::vector<instance> children;
        if (!is_valid(this->address)) {
            std::cout << "invalid address in get_character: " << (void*)this->address;
            return instance(0x0);
        }

        auto player = get_local_player();
        if (!is_valid(player)) {
            std::cout << "invalid local player in get_character:" << (void*)player.address;
            return instance(0x0);
        }
        return instance(mem->read<uintptr_t>(player.address + offsets::player::player_character));
    }
};
class script : public instance {
public:
    script(uintptr_t addr) : instance(addr) {}
    script(const instance& inst) : instance(inst.address) {}


    std::function<void()> set_script_bytecode(const std::vector<char>& bytes, size_t size) {
        uintptr_t offset = (this->get_class() == "LocalScript")
            ? offsets::script::localscript_bytecode
            : offsets::script::modulescript_bytecode;

        uintptr_t embedded = mem->read<uintptr_t>(address + offset);

        uintptr_t original_bytecode_ptr = mem->read<uintptr_t>(embedded + 0x10);
        uint64_t original_size = mem->read<uint64_t>(embedded + 0x20);

        uintptr_t newMem = mem->allocate(size, PAGE_READWRITE);
        if (!newMem) { return []() {}; }

        mem->write(newMem, bytes);
        mem->write<uintptr_t>(embedded + offsets::script::bytecode_pointer, newMem);
        mem->write<uint64_t>(embedded + offsets::script::bytecode_size, static_cast<uint64_t>(size));


        return [=]() {
            mem->write<uintptr_t>(embedded + offsets::script::bytecode_pointer, original_bytecode_ptr);
            mem->write<uint64_t>(embedded + offsets::script::bytecode_size, original_size);

            mem->free(newMem);
            };
    }
    std::function<void()> set_script_bytecode(std::string bytecode) {
        std::vector<char> bytes(bytecode.begin(), bytecode.end());
        return set_script_bytecode(bytes, bytes.size());
    }
    std::vector<char> get_script_bytecode() {
        uintptr_t offset = (this->get_class() == "LocalScript")
            ? offsets::script::localscript_bytecode
            : offsets::script::modulescript_bytecode;

        uintptr_t embedded = mem->read<uintptr_t>(address + offset);

        uintptr_t bytecode_ptr = mem->read<uintptr_t>(embedded + offsets::script::bytecode_pointer);
        uint64_t bytecode_size = mem->read<uint64_t>(embedded + offsets::script::bytecode_size);

        if (!bytecode_ptr || !bytecode_size) { return {}; }

        return mem->read<char>(bytecode_ptr, static_cast<size_t>(bytecode_size));
    }

    class vtable {
    public:
        uintptr_t address;

        explicit vtable(uintptr_t addr) : address(addr) {}
        explicit vtable(const instance& inst) : address(inst.address) {}

        uintptr_t get_function(int index) {
            return mem->read<uintptr_t>(address + index * 0x8);
        }
        // ...your own vtable-only helpers
    };
};

uintptr_t get_script_context() {
    if (!globals::datamodel) { return 0x0; }

    uintptr_t _children = mem->read<uintptr_t>(globals::datamodel + offsets::instance::children_start);
    uintptr_t children = mem->read<uintptr_t>(_children);
    return mem->read<uintptr_t>(children + offsets::datamodel::script_context);
}