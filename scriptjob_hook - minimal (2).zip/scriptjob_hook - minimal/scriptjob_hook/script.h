#pragma once

#include <Luau/Compiler.h>
#include <Luau/ParseOptions.h>
#include <Luau/BytecodeBuilder.h>
#include <Luau/Bytecode.h>
#include <Luau/BytecodeUtils.h>

#include "zstd/include/xxhash.h"
#include "zstd/include/zstd.h"
#include "offsets.h"
#include "vmvalue.h"

#include <lua.h> // just for fun to be able to use things like LUA_OK instead of just the number like 0

static std::vector<std::string> script_queue;

class bytecode_encoder_t : public Luau::BytecodeEncoder {
    inline void encode(uint32_t* data, size_t count) override {
        for (auto i = 0u; i < count;) {
            auto& opcode = *reinterpret_cast<uint8_t*>(data + i);
            i += Luau::getOpLength(LuauOpcode(opcode));
            opcode *= 227;
        }
    }
};

std::string Compress(const std::string Bytecode) {
    size_t DataSize = Bytecode.size();
    size_t MaxSize = ZSTD_compressBound(DataSize);
    std::vector<char> Buffer(MaxSize + 8);

    memcpy(Buffer.data(), "RSB1", 4);
    memcpy(Buffer.data() + 4, &DataSize, sizeof(DataSize));

    size_t CompressedSize = ZSTD_compress(Buffer.data() + 8, MaxSize, Bytecode.data(), DataSize, ZSTD_maxCLevel());
    size_t TotalSize = CompressedSize + 8;

    uint32_t Key = XXH32(Buffer.data(), TotalSize, 42);
    uint8_t* KeyBytes = (uint8_t*)&Key;

    for (size_t i = 0; i < TotalSize; ++i) Buffer[i] ^= KeyBytes[i % 4] + i * 41;

    return std::string(Buffer.data(), TotalSize);
}

std::string Compile(const std::string& source)
{
    static bytecode_encoder_t encoder = bytecode_encoder_t();

    static const char* CommonGlobals[] = { "Game", "Workspace", "game", "plugin", "script", "shared", "workspace", "_G", "_ENV", nullptr };
    Luau::CompileOptions Options;
    Options.debugLevel = 1;
    Options.optimizationLevel = 1;
    Options.mutableGlobals = CommonGlobals;
    Options.vectorLib = "Vector3";
    Options.vectorCtor = "new";
    Options.vectorType = "Vector3";

    const std::string bytecode = Luau::compile(source, Options, {}, &encoder);

    if (!bytecode.empty()) {
        if (bytecode[0] == '\0') {
            std::string bytecodeP = bytecode;
            bytecodeP.erase(std::remove(bytecodeP.begin(), bytecodeP.end(), '\0'), bytecodeP.end());
        }
    }

    return Compress(bytecode);
}

namespace execution {
    void set_top(uintptr_t state) //  hahaha get it. I put the set top function... at the top...
    {
        auto top = mem->read<uintptr_t>(state + offsets::script::lua_top);
        mem->write<uintptr_t>(state + offsets::script::lua_top, top - 0x10);
    }
    auto get_top(uintptr_t state)
    {
        return mem->read<uintptr_t>(state + offsets::script::lua_top);
    }

    void run(uintptr_t state) { 
        __try { internal::task_defer(globals::lua_state); set_top(globals::lua_state); }
        __except (EXCEPTION_EXECUTE_HANDLER) { internal::print(3, "[c] error executing"); }
    }

    static uintptr_t MaxCapabilities = MAX_CAPABILITIES;
    void execute_script(std::string script)
    {
        auto compiledAndCompressed = Compile(script);

        uintptr_t top;
        uintptr_t lclosure_addr;
        uintptr_t proto;
        switch (internal::luaVM_load(globals::lua_state, &compiledAndCompressed, "@dsi_lusploit", 0))
        {
        case LUA_OK:
            run(globals::lua_state);
            break;

        case LUA_YIELD:
            internal::print(1, "load status LUA_YIELD");
            run(globals::lua_state);
            break;

        case LUA_ERRSYNTAX:
            internal::print(3, "Script syntax error.");
            break;

        case LUA_ERRMEM:
            internal::print(3, "Script memory allocation error.");
            break;

        case LUA_ERRRUN:
            internal::print(3, "Script runtime error.");
            break;

        default:
            break;
        }
    }

    void initialize()
    {

        auto script_context = get_script_context();
        internal::print(0, "script_context: 0x%p", reinterpret_cast<void*>(script_context)); Sleep(100);

        uintptr_t c = 0;
        uintptr_t b = 0;

        auto decryptedState = internal::get_global_state_for_instance(script_context, &c, &b);

        globals::lua_state = decryptedState;
        internal::print(0, "[sc] luastate: 0x%p", reinterpret_cast<void*>(globals::lua_state));     Sleep(100);

    }

    void add_script(std::string script)
    {
        script_queue.push_back(script);
    }
}