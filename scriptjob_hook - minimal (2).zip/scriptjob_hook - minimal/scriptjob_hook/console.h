#pragma once

#include <string>
#include <Windows.h>
#include <thread>

#include "offsets.h"

bool ConsoleExists = false;
HANDLE OriginalConsoleHandle = INVALID_HANDLE_VALUE;

#define RESET    "\033[0m"
#define BRACKET  "\033[38;5;239m"
#define TIME     "\033[38;5;242m"
#define GRAY     "\033[38;5;242m"
#define CON_TEXT "\033[37m"
#define BLUE     "\033[94m"
#define ORANGE   "\033[38;5;214m"
#define RED      "\033[91m"

namespace Console {
    void EnableAnsi() {
        HANDLE OutputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
        DWORD Mode = 0;
        GetConsoleMode(OutputHandle, &Mode);
        SetConsoleMode(OutputHandle, Mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING);
        SetConsoleCP(65001);
        SetConsoleOutputCP(65001);
    }

    void BypassConsole(bool Visible) {
        PVOID Peb = (PVOID)__readgsqword(0x60);
        if (!Peb) return;

        PVOID ProcessParams = *(PVOID*)((BYTE*)Peb + 0x20);
        if (!ProcessParams) return;

        HANDLE* ConsoleHandle = (HANDLE*)((BYTE*)ProcessParams + 0x10);

        if (!Visible) {
            if (OriginalConsoleHandle == INVALID_HANDLE_VALUE)
                OriginalConsoleHandle = *ConsoleHandle;
            *ConsoleHandle = NULL;
        }
        else {
            *ConsoleHandle = OriginalConsoleHandle;
        }
    }

    std::string ReadConsoleInput() {
        HANDLE InputHandle = GetStdHandle(STD_INPUT_HANDLE);

        if (InputHandle == INVALID_HANDLE_VALUE) {
            internal::print(3, "Could not get handle!");
            return "";
        }

        char Buffer[256] = {};
        DWORD BytesRead = 0;

        BypassConsole(true);
        std::thread([] {
            Sleep(100);
            BypassConsole(false);
            }).detach();

        if (!ReadConsoleA(InputHandle, Buffer, sizeof(Buffer) - 1, &BytesRead, NULL)) {
            internal::print(3, "Error reading console!");
            return "";
        }

        Buffer[BytesRead] = '\0';

        // Remove CR/LF from Enter
        while (BytesRead > 0 &&
            (Buffer[BytesRead - 1] == '\r' ||
                Buffer[BytesRead - 1] == '\n')) {
            Buffer[--BytesRead] = '\0';
        }

        return std::string(Buffer);
    }

    void ClearConsoleScreen() {
        BypassConsole(true);

        HANDLE OutputHandle = GetStdHandle(STD_OUTPUT_HANDLE);
        if (OutputHandle == INVALID_HANDLE_VALUE) {
            BypassConsole(false);
            return;
        }

        CONSOLE_SCREEN_BUFFER_INFO ScreenInfo;
        DWORD Written;
        COORD Home = { 0, 0 };

        if (GetConsoleScreenBufferInfo(OutputHandle, &ScreenInfo)) {
            DWORD Size = ScreenInfo.dwSize.X * ScreenInfo.dwSize.Y;
            FillConsoleOutputCharacter(OutputHandle, ' ', Size, Home, &Written);
            FillConsoleOutputAttribute(OutputHandle, ScreenInfo.wAttributes, Size, Home, &Written);
            SetConsoleCursorPosition(OutputHandle, Home);
        }

        BypassConsole(false);
    }

    std::string GetTimestamp() {
        SYSTEMTIME Time;
        GetLocalTime(&Time);

        char Buffer[16];
        sprintf_s(Buffer, "%02d:%02d:%02d", Time.wHour, Time.wMinute, Time.wSecond);

        return Buffer;
    }

    void PrintFormatted(const char* TypeColor, const char* Type, const char* Text) {
        std::string Timestamp = GetTimestamp();

        printf(
            BRACKET "[" TIME "%s" BRACKET "] "
            BRACKET "[" "%s%s" BRACKET "] "
            CON_TEXT "%s" RESET "\n",
            Timestamp.c_str(),
            TypeColor, Type,
            Text
        );
    }

    int RConsoleCreate() {
        if (ConsoleExists) {
            BypassConsole(true);
            ShowWindow(GetConsoleWindow(), SW_SHOW);
            BypassConsole(false);
            return true;
        }

        if (!AllocConsole()) {
            internal::print(3, "Error Creating Console");
            return false;
        }

        FILE* File;
        freopen_s(&File, "CONOUT$", "w", stdout);
        freopen_s(&File, "CONOUT$", "w", stderr);
        freopen_s(&File, "CONOUT$", "r", stdin);

        SetConsoleTitleW(L"Roblox");
        EnableAnsi();
        BypassConsole(false);

        DWORD Mode;
        if (!GetConsoleMode(GetStdHandle(STD_OUTPUT_HANDLE), &Mode)) {
            printf("Console Loaded Successfully");
            ConsoleExists = true;
        }
        else {
            internal::print(3, "Console failed to load.");
        }

        return 0;
    }

    int RConsoleClear() {
        ClearConsoleScreen();
        return 0;
    }

    std::string RConsoleInput() {
        return ReadConsoleInput();
    }

    int RConsoleDestroy() {
        if (ConsoleExists) {
            ClearConsoleScreen();
            BypassConsole(true);
            SetConsoleTitleW(L"Roblox");
            ShowWindow(GetConsoleWindow(), SW_HIDE);
            BypassConsole(false);
        }
        return 0;
    }

    int RConsoleSetTitleL(std::string title) {

        std::wstring WideTitle(title.begin(), title.end());

        BypassConsole(true);
        SetConsoleTitleW(WideTitle.c_str());
        BypassConsole(false);

        return 0;
    }

    int RConsoleTopmost() {
        if (ConsoleExists) {
            BypassConsole(true);
            SetWindowPos(GetConsoleWindow(), HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
            BypassConsole(false);
        }
        return 0;
    }

    int RConsolePrint(std::string text) {

        BypassConsole(true);
        PrintFormatted(GRAY, "Print", text.c_str());
        BypassConsole(false);

        return 0;
    }

    int RConsoleInfo(std::string text) {

        BypassConsole(true);
        PrintFormatted(BLUE, "Info", text.c_str());
        BypassConsole(false);

        return 0;
    }

    int RConsoleWarn(std::string text) {

        BypassConsole(true);
        PrintFormatted(ORANGE, "Warning", text.c_str());
        BypassConsole(false);

        return 0;
    }

    int RConsoleErr(std::string text){

        BypassConsole(true);
        PrintFormatted(RED, "Error", text.c_str());
        BypassConsole(false);

        return 0;
    }

    int RConsoleHide() {
        BypassConsole(true);
        ShowWindow(GetConsoleWindow(), SW_HIDE);
        BypassConsole(false);
        return 0;
    }

    int RConsoleShow() {
        BypassConsole(true);
        ShowWindow(GetConsoleWindow(), SW_SHOW);
        BypassConsole(false);
        return 0;
    }

    int RConsoleToggle() {
        BypassConsole(true);

        HWND Window = GetConsoleWindow();
        if (Window)
            ShowWindow(Window, IsWindowVisible(Window) ? SW_HIDE : SW_SHOW);

        BypassConsole(false);
        return 0;
    }

    int RConsoleHidden() {
        BypassConsole(true);

        HWND Window = GetConsoleWindow();
        auto state = (Window && !IsWindowVisible(Window));

        BypassConsole(false);
        return state;
    }

}