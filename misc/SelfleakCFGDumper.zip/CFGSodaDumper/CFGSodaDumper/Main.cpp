#include <Windows.h>
#include <TlHelp32.h>
#include <Psapi.h>

#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>
#include <chrono>

#pragma comment(lib, "Psapi.lib")

DWORD GetRobloxPID()
{
    PROCESSENTRY32W pe{};
    pe.dwSize = sizeof(pe);

    HANDLE snap =
        CreateToolhelp32Snapshot(
            TH32CS_SNAPPROCESS,
            0
        );

    if (snap == INVALID_HANDLE_VALUE)
        return 0;

    if (Process32FirstW(snap, &pe))
    {
        do
        {
            if (!_wcsicmp(
                pe.szExeFile,
                L"RobloxPlayerBeta.exe"))
            {
                CloseHandle(snap);
                return pe.th32ProcessID;
            }

        } while (Process32NextW(snap, &pe));
    }

    CloseHandle(snap);

    return 0;
}

HMODULE GetRemoteModule(
    HANDLE process,
    const wchar_t* wanted,
    MODULEINFO& mi)
{
    HMODULE mods[1024];
    DWORD needed;

    if (!EnumProcessModules(
        process,
        mods,
        sizeof(mods),
        &needed))
    {
        return nullptr;
    }

    int count =
        needed / sizeof(HMODULE);

    for (int i = 0; i < count; i++)
    {
        WCHAR name[MAX_PATH]{};

        GetModuleBaseNameW(
            process,
            mods[i],
            name,
            MAX_PATH
        );

        if (!_wcsicmp(
            name,
            wanted))
        {
            GetModuleInformation(
                process,
                mods[i],
                &mi,
                sizeof(mi)
            );

            return mods[i];
        }
    }

    return nullptr;
}

uintptr_t PatternScan(
    const uint8_t* data,
    size_t size,
    const uint8_t* pattern,
    const char* mask)
{
    size_t len = strlen(mask);

    for (size_t i = 0; i <= size - len; i++)
    {
        bool found = true;

        for (size_t j = 0; j < len; j++)
        {
            if (mask[j] != '?' &&
                data[i + j] != pattern[j])
            {
                found = false;
                break;
            }
        }

        if (found)
            return i;
    }

    return 0;
}

bool DumpProtectedModule(
    HANDLE process,
    MODULEINFO& mi,
    std::vector<uint8_t>& outBuffer)
{
    outBuffer.resize(
        mi.SizeOfImage,
        0
    );

    uintptr_t base =
        (uintptr_t)mi.lpBaseOfDll;

    uintptr_t end =
        base + mi.SizeOfImage;

    uintptr_t current =
        base;

    while (current < end)
    {
        MEMORY_BASIC_INFORMATION mbi{};

        if (!VirtualQueryEx(
            process,
            (LPCVOID)current,
            &mbi,
            sizeof(mbi)))
        {
            break;
        }

        bool readable =
            mbi.State == MEM_COMMIT &&
            !(mbi.Protect & PAGE_NOACCESS) &&
            !(mbi.Protect & PAGE_GUARD);

        if (readable)
        {
            SIZE_T bytesRead;

            ReadProcessMemory(
                process,
                (LPCVOID)current,
                outBuffer.data() +
                (current - base),
                mbi.RegionSize,
                &bytesRead
            );
        }

        current += mbi.RegionSize;
    }

    return true;
}

std::string GetRobloxVersion(HANDLE process)
{
    HMODULE mods[1024];
    DWORD needed;

    if (!EnumProcessModules(
        process,
        mods,
        sizeof(mods),
        &needed))
    {
        return "unknown";
    }

    char path[MAX_PATH]{};

    GetModuleFileNameExA(
        process,
        mods[0],
        path,
        MAX_PATH
    );

    std::string fullPath =
        path;

    size_t pos =
        fullPath.find("version-");

    if (pos == std::string::npos)
        return "unknown";

    size_t end =
        fullPath.find("\\", pos);

    if (end == std::string::npos)
        end = fullPath.size();

    return fullPath.substr(
        pos,
        end - pos
    );
}

int main()
{
    auto start =
        std::chrono::high_resolution_clock::now();

    DWORD pid =
        GetRobloxPID();

    if (!pid)
    {
        std::cout
            << "Roblox not found\n";

        return 0;
    }

    HANDLE process =
        OpenProcess(
            PROCESS_ALL_ACCESS,
            FALSE,
            pid
        );

    if (!process)
    {
        std::cout
            << "OpenProcess failed\n";

        return 0;
    }

    std::string version =
        GetRobloxVersion(process);

    MODULEINFO mi{};

    HMODULE hyperion =
        GetRemoteModule(
            process,
            L"RobloxPlayerBeta.dll",
            mi
        );

    if (!hyperion)
    {
        std::cout
            << "Hyperion not found\n";

        return 0;
    }

    std::vector<uint8_t> buffer;

    DumpProtectedModule(
        process,
        mi,
        buffer
    );

    //fuck ass signature maybe survives few updates
    uint8_t sig[] =
    {
        0x4C, 0x8B, 0x1D,
        0,0,0,0,
        0x49, 0x89, 0xC2
    };

    uintptr_t match =
        PatternScan(
            buffer.data(),
            buffer.size(),
            sig,
            "xxx????xxx"
        );

    if (!match)
    {
        std::cout
            << "Signature not found\n";

        return 0;
    }

    uintptr_t cfg =
        match - 0xF;

    int32_t disp =
        *(int32_t*)(
            buffer.data() +
            match +
            3
            );

    uintptr_t nextInstr =
        (uintptr_t)mi.lpBaseOfDll +
        match +
        7;

    uintptr_t bitmapVA =
        nextInstr + disp;

    uintptr_t bitmap =
        bitmapVA -
        (uintptr_t)mi.lpBaseOfDll;

    uint8_t byteShift =
        buffer[match + 0x19];

    uint8_t pageShift =
        buffer[match + 0x25];

    uint8_t bitMask =
        buffer[match + 0x29];

    uintptr_t pageSize =
        1ULL << pageShift;

    uintptr_t pageMask =
        pageSize - 1;

    auto end =
        std::chrono::high_resolution_clock::now();

    double ms =
        std::chrono::duration<double, std::milli>(
            end - start
        ).count();

    char exePath[MAX_PATH]{};

    GetModuleFileNameA(
        nullptr,
        exePath,
        MAX_PATH
    );

    std::string fullPath =
        exePath;

    size_t slash =
        fullPath.find_last_of("\\/");

    fullPath =
        fullPath.substr(
            0,
            slash + 1
        );

    fullPath += "offsets.hpp";

    std::ofstream out(
        fullPath
    );

    out << "#pragma once\n\n";

    out << "/*\n";
    out << "    Soda.lol CFG Dumper v1.0\n";
    out << "    Made by Cabe\n\n";

    out << "    Roblox Version: "
        << version << "\n";

    out << "    Dump Time: "
        << std::fixed
        << std::setprecision(2)
        << ms
        << "ms\n";

    out << "    Total Offsets: 7\n";
    out << "*/\n\n";

    out << "namespace Reversal\n";
    out << "{\n";

    out << "    static const uintptr_t ControlFlowGuard = 0x"
        << std::uppercase
        << std::hex
        << cfg
        << ";\n";

    out << "    static const uintptr_t BitMap = 0x"
        << bitmap
        << ";\n\n";

    out << "    enum Offsets\n";
    out << "    {\n";

    out << "        ByteShift = "
        << std::dec
        << (int)byteShift
        << ",\n";

    out << "        PageShift = "
        << (int)pageShift
        << ",\n";

    out << "        BitMask = "
        << (int)bitMask
        << ",\n";

    out << "        PageSize = 0x"
        << std::uppercase
        << std::hex
        << pageSize
        << ",\n";

    out << "        PageMask = 0x"
        << pageMask
        << "\n";

    out << "    };\n";
    out << "};\n";

    out.close();

    std::cout
        << "=====================================\n";

    std::cout
        << "Soda.lol CFG Dumper v1.0\n";

    std::cout
        << "Made by Cabe\n";

    std::cout
        << "=====================================\n\n";

    std::cout
        << "Roblox Version: "
        << version
        << "\n";

    std::cout
        << std::fixed
        << std::setprecision(2);

    std::cout
        << "Dump Time: "
        << ms
        << "ms\n";

    std::cout
        << "Total Offsets: 7\n\n";

    std::cout
        << std::uppercase
        << std::hex;

    std::cout
        << "ControlFlowGuard: 0x"
        << cfg
        << "\n";

    std::cout
        << "BitMap: 0x"
        << bitmap
        << "\n";

    std::cout
        << std::dec;

    std::cout
        << "ByteShift: "
        << (int)byteShift
        << "\n";

    std::cout
        << "PageShift: "
        << (int)pageShift
        << "\n";

    std::cout
        << "BitMask: "
        << (int)bitMask
        << "\n";

    std::cout
        << std::uppercase
        << std::hex;

    std::cout
        << "PageSize: 0x"
        << pageSize
        << "\n";

    std::cout
        << "PageMask: 0x"
        << pageMask
        << "\n\n";

    std::cout
        << "offsets.hpp dumped successfully\n";

    CloseHandle(process);

    std::cin.get();

    return 0;
} // nigga ass shit