#include "proc.h"

#include <Psapi.h>


/*
    made by volxphy

*/

DWORD Process::getPid() {
	if (windowName.empty())
		return 0;

	HWND h = FindWindowA(nullptr, windowName.c_str());
	if (!h) return 0;

	DWORD pid;
	GetWindowThreadProcessId(h, &pid);
	return pid;

}

HANDLE Process::getHandle(DWORD desiredAccess) {
	if (!pid)
		pid = getPid();

	DWORD acc = desiredAccess ? desiredAccess : PROCESS_ALL_ACCESS;
	HANDLE h = OpenProcess(acc, FALSE, pid);

	return h;
}


uint64_t Process::getModuleBaseAddress(const std::string& moduleName) {
    if (!hProc)
        return 0;

    HMODULE modules[1024]{};
    DWORD bytesNeeded = 0;

    if (!EnumProcessModulesEx(hProc, modules, sizeof(modules), &bytesNeeded, LIST_MODULES_ALL))
        return 0;

    const DWORD moduleCount = bytesNeeded / sizeof(HMODULE);

    for (DWORD i = 0; i < moduleCount; ++i) {
        char currentName[MAX_PATH]{};

        if (!GetModuleBaseNameA(hProc, modules[i], currentName, static_cast<DWORD>(std::size(currentName))))
            continue;

        if (_stricmp(currentName, moduleName.c_str()) == 0) {
            return reinterpret_cast<uint64_t>(modules[i]);
        }
    }

    return 0;
}
