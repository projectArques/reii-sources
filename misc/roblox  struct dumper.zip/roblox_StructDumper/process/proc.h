#pragma once
#include <Windows.h>
#include <iostream>


class Process {
private:
	std::string windowName;
	DWORD pid;
	HANDLE hProc;


	DWORD getPid();
	HANDLE getHandle(DWORD desiredAccess);
public:
	Process(const std::string& window, DWORD desiredAccess = PROCESS_ALL_ACCESS - 0x1) : windowName(window) {
		pid = getPid();
		hProc = getHandle(desiredAccess);
	};

	~Process() {
		windowName.clear();
		pid = 0;
		hProc = 0;
	};

	DWORD processId() { return pid; }
	HANDLE handle() { return hProc; };

	uint64_t getModuleBaseAddress(const std::string& moduleName);
};
/*
	made by volxphy

*/