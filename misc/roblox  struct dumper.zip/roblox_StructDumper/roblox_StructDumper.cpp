#include <iostream>
#include <Windows.h>
#include <memory>

#include "essentials/logs.h"
#include "process/proc.h"
#include "memory/mem.h"
#include "dumper/dumper.h"

extern "C" void handleException();

/*
	made by volxphy

*/

LONG CALLBACK veh(EXCEPTION_POINTERS* ex) {
	if (ex->ContextRecord->Rcx == 676767)
		exit(1);
	ex->ContextRecord->Rip = (uint64_t)&handleException;
	return EXCEPTION_CONTINUE_EXECUTION;
}

int main()
{
	SetConsoleTitleA("Roblox struct Dumper");
	AddVectoredExceptionHandler(1, veh);

	std::unique_ptr<Process> roblox = std::make_unique<Process>("Roblox");
	std::unique_ptr<Mem> rMem = std::make_unique<Mem>(roblox.get());
	DWORD pid = roblox->processId();
	if (!pid) {
		Log::error("Roblox not found!");
		getchar();
		return 1;
	}
	HANDLE hProc = roblox->handle();
	uint64_t robloxBase = roblox->getModuleBaseAddress("RobloxPlayerBeta.exe");

	Log::info("Made by @Volxphy\n");

	Log::warn("pid -> %d", pid);
	Log::warn("handle -> 0x%llx", hProc);
	Log::warn("Base -> 0x%llx", robloxBase);

	IMAGE_SECTION_HEADER text{};
	if (!rMem->findSection(robloxBase, ".text", &text)) {
		Log::error("failed to find .text!");
		getchar();
		return 1;
	}

	auto secBase = text.VirtualAddress + robloxBase;
	auto secSize = text.Misc.VirtualSize;

	uint64_t mappedRegion = rMem->mapMemory(secBase, secSize);
	Log::info("Mapped to -> 0x%llx", mappedRegion);
	Log::warn("Decrypting pages... (ETA: ~12sec)"); // threaded
	Log::error("please join a game now!");

	Dumper dumper(roblox.get(), mappedRegion, robloxBase, text.VirtualAddress);

	Sleep(12000);

	int globalGcstatsSize = 184;

	uint64_t luaF_freeproto = dumper.sigScanUnique("48 89 5C 24 ? 48 89 74 24 ? 57 48 83 EC ? 44 0F B6 4A", secSize);
	Log::info("luaF_freeproto -> 0x%llx", dumper.vaToRvaMap(luaF_freeproto));
	
	uint64_t dumptable = dumper.sigScanUnique("44 8B 4A ? 48 8B CB", secSize);
	Log::info("dumptable -> 0x%llx", dumper.vaToRvaMap(dumptable));

	uint64_t dumpThread = dumper.sigScanUnique("48 83 EC ? 8B 42 ? 4C 8D 4A", secSize);
	Log::info("dumpThread -> 0x%llx", dumper.vaToRvaMap(dumpThread));

	uint64_t propagatemark = dumper.sigScanUnique("48 83 EC ? 48 8B 59 ? 48 8B F9 80 4B", secSize);
	Log::info("propagatemark -> 0x%llx", dumper.vaToRvaMap(propagatemark));

	uint64_t gcstep = dumper.sigScanUnique("44 0F B6 47 ? 45 85 C0", secSize);
	Log::info("gcstep -> 0x%llx", dumper.vaToRvaMap(gcstep));

	uint64_t newpage = dumper.sigScanUnique("48 89 5C 24 ? 48 89 6C 24 ? 48 89 74 24 ? 57 48 83 EC ? 48 8B F1 49 63 E8", secSize);
	Log::info("newpage -> 0x%llx", dumper.vaToRvaMap(newpage));

	// COMMONHEADER
	uint64_t memcat = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVZX, 0);
	uint64_t marked = dumper.findNext(propagatemark, ZYDIS_MNEMONIC_OR, 0);

	// PROTO
	uint64_t sizecode = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVSXD, 0);
	uint64_t code = dumper.findNext(sizecode, ZYDIS_MNEMONIC_MOV, 1);
	uint64_t sizep = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVSXD, 1);
	uint64_t p = dumper.findNext(sizep, ZYDIS_MNEMONIC_MOV, 1);
	uint64_t sizek = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVSXD, 2);
	uint64_t k = dumper.findNext(sizek, ZYDIS_MNEMONIC_MOV, 1);
	uint64_t lineinfo = dumper.findNext(k, ZYDIS_MNEMONIC_MOV, 1); // SUB MIGHT BE ENC
	uint64_t sizelineinfo = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVSXD, 3);
	uint64_t sizelocvars = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVSXD, 4);
	uint64_t locvars = dumper.findNext(sizelocvars, ZYDIS_MNEMONIC_LEA, 0);
	uint64_t upvalues = dumper.findNext(locvars, ZYDIS_MNEMONIC_LEA, 2);
	uint64_t sizeupvalues = dumper.findNext(luaF_freeproto, ZYDIS_MNEMONIC_MOVSXD, 5);
	uint64_t debuginsn = dumper.findNext(sizeupvalues, ZYDIS_MNEMONIC_MOV, 1);
	uint64_t execdata = dumper.findNext(dumper.findNext(debuginsn, ZYDIS_MNEMONIC_CALL, 0), ZYDIS_MNEMONIC_CMP, 0);
	uint64_t typeinfo = dumper.findNext(execdata, ZYDIS_MNEMONIC_LEA, 0);
	uint64_t sizeofProto = dumper.findNext(typeinfo, ZYDIS_MNEMONIC_MOV, 1);
	uint64_t source = dumper.findNext(dumper.findNext(dumpThread, ZYDIS_MNEMONIC_JNZ, 0), ZYDIS_MNEMONIC_MOV, 3);
	uint64_t linedefined = dumper.findNext(dumper.findNext(source, ZYDIS_MNEMONIC_CALL, 0), ZYDIS_MNEMONIC_MOV, 0);

	// LUASTATE
	uint64_t global = dumper.findNext(execdata, ZYDIS_MNEMONIC_MOV, 0);
	uint64_t stacksize = dumper.findNext(dumpThread, ZYDIS_MNEMONIC_LEA, 0);
	uint64_t size_ci = stacksize - 0x3;
	uint64_t gt = dumper.findNext(dumper.findNext(size_ci, ZYDIS_MNEMONIC_MOVZX, 0), ZYDIS_MNEMONIC_MOV, 1);
	uint64_t base_ci = dumper.findNext(gt, ZYDIS_MNEMONIC_MOV, 2);
	uint64_t ci = base_ci + 0x4;
	uint64_t top = dumper.findNext(linedefined, ZYDIS_MNEMONIC_CMP, 0);
	uint64_t stack = dumper.findNext(linedefined, ZYDIS_MNEMONIC_MOV, 2);

	// LUATABLE
	uint64_t node = dumper.findNext(dumptable, ZYDIS_MNEMONIC_CMP, 0);
	uint64_t lsizenode = dumper.findNext(node, ZYDIS_MNEMONIC_MOVZX, 0);
	uint64_t sizearray = dumper.findNext(dumper.findNext(lsizenode, ZYDIS_MNEMONIC_ADD, 1), ZYDIS_MNEMONIC_CMP, 1);
	uint64_t array = dumper.findNext(dumper.findNext(sizearray, ZYDIS_MNEMONIC_MOVSXD, 0), ZYDIS_MNEMONIC_MOV, 1);
	uint64_t metatable = dumper.findNext(array, ZYDIS_MNEMONIC_CMP, 0);
	uint64_t gclist = dumper.findNext(dumper.findNext(propagatemark, ZYDIS_MNEMONIC_RET, 0), ZYDIS_MNEMONIC_MOV, 0);


	// GLOBALSTATE
	uint64_t gray = dumper.findNext(propagatemark, ZYDIS_MNEMONIC_MOV, 0);
	uint64_t gcstate = dumper.findNext(gcstep, ZYDIS_MNEMONIC_MOVZX, 0);
	uint64_t gcstats = dumper.findNext(dumper.findNext(gcstep, ZYDIS_MNEMONIC_CMP , 9), ZYDIS_MNEMONIC_MOV, 1);
	uint64_t frealloc = dumper.findNext(dumper.findNext(newpage, ZYDIS_MNEMONIC_XOR , 0), ZYDIS_MNEMONIC_MOV, 0);
	uint64_t ud = dumper.findNext(dumper.findNext(newpage, ZYDIS_MNEMONIC_XOR , 0), ZYDIS_MNEMONIC_MOV, 1);


	printf("\n");
	Log::warn("COMMONHEADER MACRO");
	Log::info("x->memcat = 0x%llx", dumper.getDisplacement(memcat)); // 2
	Log::info("x->marked = 0x%llx", dumper.getDisplacement(marked)); // 1
	Log::info("x->tt = 0x%llx", dumper.getDisplacement(marked) > dumper.getDisplacement(memcat) ? dumper.getDisplacement(memcat) - 1 : dumper.getDisplacement(marked) - 1); // sps to be 0


	printf("\n");
	Log::warn("PROTO STRUCT (reserved 0x0 - 0x2 CommonHeader)");
	Log::info("proto->sizecode = 0x%llx", dumper.getDisplacement(sizecode));
	Log::info("proto->code = 0x%llx", dumper.getDisplacement(code));
	Log::info("proto->sizep = 0x%llx", dumper.getDisplacement(sizep));
	Log::info("proto->p = 0x%llx", dumper.getDisplacement(p));
	Log::info("proto->sizek = 0x%llx", dumper.getDisplacement(sizek));
	Log::info("proto->k = 0x%llx", dumper.getDisplacement(k));
	Log::info("proto->lineinfo = 0x%llx", dumper.getDisplacement(lineinfo));
	Log::info("proto->sizelineinfo = 0x%llx", dumper.getDisplacement(sizelineinfo));
	Log::info("proto->sizelocvars = 0x%llx", dumper.getDisplacement(sizelocvars));
	Log::info("proto->locvars = 0x%llx", dumper.getDisplacement(locvars));
	Log::info("proto->upvalues = 0x%llx", dumper.getDisplacement(upvalues));
	Log::info("proto->sizeupvalues = 0x%llx", dumper.getDisplacement(sizeupvalues));
	Log::info("proto->debuginsn = 0x%llx", dumper.getDisplacement(debuginsn));
	Log::info("proto->execdata = 0x%llx", dumper.getDisplacement(execdata));
	Log::info("proto->typeinfo = 0x%llx", dumper.getDisplacement(typeinfo));
	Log::info("proto->source = 0x%llx", dumper.getDisplacement(source));
	Log::info("proto->linedefined = 0x%llx", dumper.getDisplacement(linedefined));
	Log::info("sizeof(Proto) = %d", (int)dumper.getData(sizeofProto));


	printf("\n");
	Log::warn("LUASTATE STRUCT (reserved 0x0 - 0x2 CommonHeader)");
	Log::info("lState->global = 0x%llx", dumper.getDisplacement(global));
	Log::info("lState->stacksize = 0x%llx", dumper.getDisplacement(stacksize));
	Log::info("lState->size_ci = 0x%llx", dumper.getDisplacement(size_ci));
	Log::info("lState->gt = 0x%llx", dumper.getDisplacement(gt));
	Log::info("lState->base_ci = 0x%llx", dumper.getDisplacement(base_ci));
	Log::info("lState->ci = 0x%llx", dumper.getDisplacement(ci));
	Log::info("lState->top = 0x%llx", dumper.getDisplacement(top));
	Log::info("lState->stack = 0x%llx", dumper.getDisplacement(stack));

	printf("\n");
	Log::warn("LUATABLE STRUCT (reserved 0x0 - 0x2 CommonHeader)");
	Log::info("lTable->node = 0x%llx", dumper.getDisplacement(node));
	Log::info("lTable->lsizenode = 0x%llx", dumper.getDisplacement(lsizenode));
	Log::info("lTable->sizearray = 0x%llx", dumper.getDisplacement(sizearray));
	Log::info("lTable->array = 0x%llx", dumper.getDisplacement(array));
	Log::info("lTable->metatable = 0x%llx", dumper.getDisplacement(metatable));
	Log::info("lTable->gclist = 0x%llx", dumper.getDisplacement(gclist));

	printf("\n");
	Log::warn("GLOBALSTATE STRUCT");
	Log::info("gState->gray = 0x%llx", dumper.getDisplacement(gray));
	Log::info("gState->gcstate = 0x%llx", dumper.getDisplacement(gcstate));
	Log::info("gState->gcstats = 0x%llx", dumper.getDisplacement(gcstats) - globalGcstatsSize + 0x8);
	Log::info("gState->frealloc = 0x%llx", dumper.getDisplacement(frealloc));
	Log::info("gState->ud = 0x%llx", dumper.getDisplacement(ud));



	getchar();
	VirtualFreeEx(roblox->handle(), (PVOID)mappedRegion, secSize, MEM_DECOMMIT);
	roblox.reset();

	return 0;
}
