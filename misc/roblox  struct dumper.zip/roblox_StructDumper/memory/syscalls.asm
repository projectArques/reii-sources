PUBLIC NtOpenProcess
PUBLIC NtWriteVirtualMemory
PUBLIC NtReadVirtualMemory
PUBLIC NtProtectVirtualMemory

; made by @volxphy. Syscalls from https://j00ru.vexillium.org/syscalls/nt/64/ <3
; TESTED ON WINDOWS11 23H2, 24H2



.data ;		NAME										ID			IGNORE

			NtOpenProcessSyscallId				db		026h,		0
			NtWriteVirtualMemorySyscallId		db		03Ah,		0
			NtReadVirtualMemorySyscallId		db		03Fh,		0
			NtProtectVirtualMemorySyscallId		db		050h,		0




.code
	NtOpenProcess PROC
		mov r10, rcx
		mov eax, DWORD PTR [NtOpenProcessSyscallId]
		syscall
		ret
	NtOpenProcess ENDP

	NtWriteVirtualMemory PROC
		mov r10, rcx
		mov eax, DWORD PTR [NtWriteVirtualMemorySyscallId]	
		syscall
		ret
	NtWriteVirtualMemory ENDP

	NtReadVirtualMemory PROC
		mov r10, rcx
		mov eax, DWORD PTR [NtReadVirtualMemorySyscallId]
		syscall
		ret
	NtReadVirtualMemory ENDP

	NtProtectVirtualMemory PROC
		mov r10, rcx
		mov eax, DWORD PTR [NtProtectVirtualMemorySyscallId]
		syscall
		ret
	NtProtectVirtualMemory ENDP

END