#include "mem.h"
#include "structs.h"
#include "process/proc.h"
#include "essentials/logs.h"

#include <memory>
#include <tuple>
#include <thread>
/*
	made by volxphy

*/
#define STATUS_SUCCESS 0x000000000
#define PAGE_SIZE 0x1000

pageInfo* Mem::getPageInfo(uint64_t pageAddr) {
	MEMORY_BASIC_INFORMATION mbi{};
	if (!VirtualQueryEx(pProcess->handle(), (PVOID)pageAddr, &mbi, sizeof(MEMORY_BASIC_INFORMATION)))
		return nullptr;

	std::unique_ptr<pageInfo> local = std::make_unique<pageInfo>();

	local->protection = mbi.Protect;
	local->baseAddr = (uint64_t)mbi.BaseAddress;
	local->baseAlloc = (uint64_t)mbi.AllocationBase;
	local->size = mbi.RegionSize;

	return local.release();
}

BOOLEAN Mem::findSection(uint64_t module, const std::string& secName, PIMAGE_SECTION_HEADER secHeaderOUT) {
	IMAGE_DOS_HEADER dosHeader = read<IMAGE_DOS_HEADER>(module);
	if (dosHeader.e_magic != IMAGE_DOS_SIGNATURE)
		return false;

	uintptr_t ntHeadersAddr = module + dosHeader.e_lfanew;
	IMAGE_NT_HEADERS ntHeaders = read<IMAGE_NT_HEADERS>(ntHeadersAddr);

	WORD numOfSections = ntHeaders.FileHeader.NumberOfSections;

	uintptr_t firstSectionAddr = ntHeadersAddr +
		FIELD_OFFSET(IMAGE_NT_HEADERS, OptionalHeader) +
		ntHeaders.FileHeader.SizeOfOptionalHeader;

	std::vector<IMAGE_SECTION_HEADER> sections(numOfSections);
	if (!ReadProcessMemory(pProcess->handle(), (LPCVOID)firstSectionAddr, sections.data(),
		numOfSections * sizeof(IMAGE_SECTION_HEADER), nullptr)) {
		return false;
	}

	for (int i = 0; i < numOfSections; ++i) {
		if (strncmp(reinterpret_cast<const char*>(sections[i].Name),
			secName.c_str(), IMAGE_SIZEOF_SHORT_NAME) == 0) {
			*secHeaderOUT = sections[i];
			return true;
		}
	}
	return false;
}

uint64_t Mem::mapMemory(const uint64_t start, const size_t size) {
	PVOID remote = VirtualAllocEx(pProcess->handle(), nullptr, size, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);

	for (uintptr_t i = 0; i < size; i += PAGE_SIZE) {
		uintptr_t currentPage = start + i;
		pageInfo* pI = getPageInfo(currentPage);
		if (pI->protection == PAGE_NOACCESS) {
			encryptedPage* p = new encryptedPage;
			p->pageIndex = i;
			p->rbxVa = currentPage;
			unmappedRegions.push_back(p);
			delete pI;
			continue;
		}
		auto buf = readBytesBuf(pI->baseAddr);
		writeVirtualMemory(((uintptr_t)remote + i), buf.data(), buf.size(), nullptr);
		delete pI;
	}

	std::thread([remote, this]() -> void {
		while (true) {
			size_t vecSize = unmappedRegions.size();
			for (int i = static_cast<int>(vecSize) - 1; i >= 0; --i) {
				if (i >= static_cast<int>(unmappedRegions.size())) continue;
				encryptedPage* page = unmappedRegions[i];
				if (page->isDecrypted) continue;
				pageInfo* pI = getPageInfo(page->rbxVa);
				if (pI->protection == PAGE_NOACCESS) continue;
				auto buf = readBytesBuf(page->rbxVa);
				writeVirtualMemory(((uintptr_t)remote + page->pageIndex), buf.data(), buf.size(), nullptr);
				page->isDecrypted = true;
			}
			Sleep(10);
		}
	}).detach();

	return (uint64_t)remote;
}

std::vector<uint8_t> Mem::readBytesBuf(uint64_t addr, size_t size) {
	std::vector<uint8_t> buf(size);
	readVirtualMemory(addr, buf.data(), size, nullptr);
	buf.resize(size);
	return buf;
}

NTSTATUS Mem::readVirtualMemory(uint64_t virtualAddress, void* buffer, size_t size, size_t* bytesRead) {
	NTSTATUS status = STATUS_SUCCESS;
	status = NtReadVirtualMemory(pProcess->handle(), (PVOID)virtualAddress, buffer, size, bytesRead);
	return status;
}

NTSTATUS Mem::writeVirtualMemory(uint64_t virtualAddress, void* buffer, size_t size, size_t* bytesWritten) {
	NTSTATUS status = STATUS_SUCCESS;
	status = NtWriteVirtualMemory(pProcess->handle(), (PVOID)virtualAddress, buffer, size, bytesWritten);
	return status;
}

NTSTATUS Mem::protectVirtualMemory(uint64_t virtualAddress, DWORD newProtection, SIZE_T regionSize, PDWORD oldProtection) {
	NTSTATUS status = STATUS_SUCCESS;
	PVOID base = (PVOID)virtualAddress;

	status = NtProtectVirtualMemory(pProcess->handle(), &base, &regionSize, newProtection, oldProtection);
	return status;
}

BOOLEAN Mem::patchAddress(uint64_t lpBase, std::vector<uint8_t> bytes) {
	NTSTATUS status = STATUS_SUCCESS;
	DWORD op;
	status = protectVirtualMemory(lpBase, PAGE_EXECUTE_READWRITE, bytes.size(), &op);
	if (status > 0)
		return false;
	status = writeVirtualMemory(lpBase, bytes.data(), bytes.size(), nullptr);
	if (status > 0)
		return false;
	return true;
}


