#pragma once
#include <Windows.h>
#include <winternl.h>
/*
	SYSCALLS

*/

typedef CLIENT_ID* PCLIENT_ID;

extern "C" NTSTATUS NtOpenProcess(
	PHANDLE            ProcessHandle,
	ACCESS_MASK        DesiredAccess,
	POBJECT_ATTRIBUTES ObjectAttributes,
	PCLIENT_ID ClientId // PCLIENT_ID
);

extern "C" NTSTATUS NtWriteVirtualMemory(
	HANDLE h,
	PVOID addr,
	PVOID buffer,
	SIZE_T size,
	PSIZE_T bytesWritten
);

extern "C" NTSTATUS NtReadVirtualMemory(
	HANDLE h,
	PVOID addr,
	PVOID buffer,
	SIZE_T size,
	PSIZE_T bytesRead
);

extern "C" NTSTATUS NtProtectVirtualMemory(
	HANDLE h,
	PVOID* baseAddr,
	PSIZE_T size,
	ULONG newProtection,
	PULONG oldProtection
);