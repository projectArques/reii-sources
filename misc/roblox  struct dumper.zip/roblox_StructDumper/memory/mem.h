#pragma once
#include <Windows.h>
#include <iostream>
#include <vector>
class Process; // forwarding to rape the compiler

struct pageInfo {
	uint64_t protection;
	size_t size;
	uint64_t baseAddr;
	uint64_t baseAlloc;
};

struct encryptedPage {
	uint64_t rbxVa;
	uint64_t pageIndex; // divide by 0x1000
	bool isDecrypted = false;
};

class Mem {
private:
	Process* pProcess;
	std::vector<encryptedPage*> unmappedRegions{};

public:
	Mem(Process* process) : pProcess(process) {};
	~Mem() {};

	pageInfo* getPageInfo(uint64_t pageAddr);
	uint64_t mapMemory(const uint64_t start, const size_t size);
	std::vector<uint8_t> readBytesBuf(uint64_t addr, size_t size = 0x1000); // one page


	NTSTATUS writeVirtualMemory(uint64_t virtualAddress, void* buffer, size_t size, size_t* bytesWritten);
	NTSTATUS readVirtualMemory(uint64_t virtualAddress, void* buffer, size_t size, size_t* bytesRead);
	NTSTATUS protectVirtualMemory(uint64_t virtualAddress, DWORD newProtection, SIZE_T regionSize, PDWORD oldProtection);

	BOOLEAN patchAddress(uint64_t lpBase, std::vector<uint8_t> bytes);
	BOOLEAN findSection(uint64_t module, const std::string& secName, PIMAGE_SECTION_HEADER secHeaderOUT);

	



	template <typename T>
	T read(uint64_t addr) {
		T buf{  };
		readVirtualMemory(addr, &buf, sizeof(T), nullptr);
		return buf;
	}

	template <typename T>
	void write(uint64_t addr, T value) {
		writeVirtualMemory(addr, &addr, sizeof(T), nullptr);
	}
};
