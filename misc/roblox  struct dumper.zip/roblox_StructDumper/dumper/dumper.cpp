#include "dumper.h"
#include "process/proc.h"

#include <vector>
#include <memory>
#include <sstream>
#include <Zydis/Zydis.h>


uint64_t Dumper::rebaseStatic(uint64_t va) {
	return ((va - allocBase) + base);
}
uint64_t Dumper::vaToRvaMap(uint64_t va) {
	return ((va - allocBase) + additionalOffset);
}

uint64_t Dumper::sigScanUnique(const std::string& signatureBytesAndWildCard, size_t size) {
	if (!pProcess->handle() || pProcess->handle() == INVALID_HANDLE_VALUE) return 0;

	std::vector<int> pat;
	std::istringstream iss(signatureBytesAndWildCard);
	std::string t;
	while (iss >> t) {
		for (auto& c : t) c = (char)toupper(c);
		if (t == "?" || t == "??") pat.push_back(-1);
		else {
			try {
				pat.push_back(std::stoul(t, nullptr, 16) & 0xFF);
			}
			catch (...) {
				pat.push_back(-1);
			}
		}
	}

	SIZE_T patLen = pat.size();
	if (patLen == 0 || patLen > size) return 0;

	std::vector<unsigned char> buf;
	buf.reserve(size);

	SIZE_T totalRead = 0;
	while (totalRead < size) {
		SIZE_T chunkSize = min(size - totalRead, (SIZE_T)0x100000);
		std::vector<unsigned char> chunk(chunkSize);
		SIZE_T bytesRead;

		if (!ReadProcessMemory(pProcess->handle(), (LPCVOID)(allocBase + totalRead),
			chunk.data(), chunkSize, &bytesRead) || bytesRead == 0) {
			return 0;
		}

		buf.insert(buf.end(), chunk.data(), chunk.data() + bytesRead);
		totalRead += bytesRead;

		if (bytesRead < chunkSize) break;
	}

	if (buf.size() < patLen) return 0;

	for (SIZE_T i = 0; i + patLen <= buf.size(); ++i) {
		bool found = true;
		for (SIZE_T j = 0; j < patLen; ++j) {
			int patternByte = pat[j];
			if (patternByte != -1 && buf[i + j] != static_cast<unsigned char>(patternByte)) {
				found = false;
				break;
			}
		}
		if (found) return allocBase + i;
	}

	return 0;
}

uint64_t Dumper::getData(uintptr_t VA) {
    ZydisDecoder decoder;
    ZydisDecoderInit(&decoder, ZYDIS_MACHINE_MODE_LONG_64, ZYDIS_STACK_WIDTH_64);

    uint8_t buffer[32];
    SIZE_T bytesRead;

    if (!ReadProcessMemory(pProcess->handle(), (LPCVOID)VA, buffer, sizeof(buffer), &bytesRead) || bytesRead == 0) {
        return 0;
    }

    ZydisDecodedInstruction instruction;
    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];

    if (!ZYAN_SUCCESS(ZydisDecoderDecodeFull(&decoder, buffer, bytesRead, &instruction, operands))) {
        return 0;
    }

    // Check for immediate operand (e.g., mov reg, imm)
    for (uint32_t i = 0; i < instruction.operand_count; i++) {
        const ZydisDecodedOperand& op = operands[i];

        if (op.type == ZYDIS_OPERAND_TYPE_IMMEDIATE) {
            return op.imm.value.u;
        }
    }

    return 0;
}

uint64_t Dumper::getDisplacement(uintptr_t instrVA) {
    ZydisDecoder decoder;
    ZydisDecoderInit(&decoder, ZYDIS_MACHINE_MODE_LONG_64, ZYDIS_STACK_WIDTH_64);

    uint8_t buffer[32];
    SIZE_T bytesRead;

    if (!ReadProcessMemory(pProcess->handle(), (LPCVOID)instrVA, buffer, sizeof(buffer), &bytesRead) || bytesRead == 0) {
        return 0;
    }

    ZydisDecodedInstruction instruction;
    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];

    if (!ZYAN_SUCCESS(ZydisDecoderDecodeFull(&decoder, buffer, bytesRead, &instruction, operands))) {
        return 0;
    }

    // Scan memory operands for displacement
    for (uint32_t i = 0; i < instruction.operand_count; i++) {
        const ZydisDecodedOperand& op = operands[i];

        if (op.type == ZYDIS_OPERAND_TYPE_MEMORY) {
            // Any non-zero displacement value indicates [reg+offset]
            if (op.mem.disp.value != 0) {
                return (uint64_t)(uint32_t)op.mem.disp.value;
            }
        }
    }

    return 0;
}



uint64_t Dumper::findNext(uintptr_t start, ZydisMnemonic_ instr, int skipHits) {
    ZydisDecoder decoder;
    ZydisDecoderInit(&decoder, ZYDIS_MACHINE_MODE_LONG_64, ZYDIS_STACK_WIDTH_64);

    uint8_t buffer[32];
    SIZE_T bytesRead;
    ZydisDecodedInstruction instruction;
    ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
    int hits = 0;

    uintptr_t current = start;
    while (true) {
        if (!ReadProcessMemory(pProcess->handle(), (LPCVOID)current, buffer, sizeof(buffer), &bytesRead) || bytesRead == 0) {
            break;
        }

        ZyanStatus status = ZydisDecoderDecodeInstruction(&decoder, nullptr, buffer, bytesRead, &instruction);
        if (ZYAN_SUCCESS(status)) {
            if (instruction.mnemonic == instr) {
                if (skipHits-- == 0) {
                    return current;
                }
            }
        }

        current += instruction.length ? instruction.length : 1;
    }

    return 0;
}

