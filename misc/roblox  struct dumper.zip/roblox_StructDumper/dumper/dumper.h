#pragma once
#include <Windows.h>
#include <iostream>
#include <vector>
#include <zydis/Decoder.h>

class Process;



class Dumper {
private:
	Process* pProcess;
	uint64_t mainBase;
	uint64_t allocBase;
	uint64_t additionalOffset;
	uint64_t base;
public:
	Dumper(Process* proc, uint64_t allocBaseA, uint64_t mainBaseA, uint64_t additionalOffsetA) : pProcess(proc){
		mainBase = mainBaseA;
		allocBase = allocBaseA;
		additionalOffset = additionalOffsetA;
		base = mainBaseA + additionalOffsetA; // e.G. moduleBase + sectionVA
	}

	uint64_t getData(uintptr_t VA);
	uint64_t getDisplacement(uintptr_t instrVA);
	uint64_t sigScanUnique(const std::string& signatureBytesAndWildCard, size_t size);

	// translating typeshit
	uint64_t rebaseStatic(uint64_t va);
	uint64_t vaToRvaMap(uint64_t va);
	

	uint64_t findNext(uintptr_t start, ZydisMnemonic_ instr, int skipHits); // ZYDIS

};
