PUBLIC handleException

EXTERN MessageBoxA:PROC




.data
	errTitle db "Unhandled Exception", 0
	errCap db "An unexpected error occurred. This program will end now.", 0

.code
	handleException PROC
		sub rsp, 28h
		mov r9, 10h
		lea r8, errTitle
		lea rdx, errCap
		xor rcx, rcx
		call MessageBoxA
		xor rax, rax
		mov rcx, 676767
		add rsp, 28h
		ret
	handleException ENDP
	

END