by: ccodix
My discord server: https://discord.gg/dP6hrWhpp
